﻿using ACS.SPiiPlusNET;
using BDTranslate.Models;
using HZH_Controls.Forms;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Windows.Forms;
using MaterialSkin;
using MaterialSkin.Controls;


namespace 预调试助手
{
    public partial class winMain : MaterialForm
    {
        #region 定义变量
        private readonly MaterialSkinManager materialSkinManager;

        Api channel;

        private Label[] m_lblLeftLimit;
        private Label[] m_lblRightLimit;
        private Label[] m_lblFatult;

        private MotorStates m_nMotorState;
        private object m_objReadVar = null;
        private Array m_arrReadVector = null;
        private double m_PE;

        private const int MAX_UI_LIMIT_CNT = 64;

        int m_axis_count;

        private TranClass tranClass = new TranClass();

        private Axis[] m_arrAxisList = null;

        #endregion
        #region 初始化
        public winMain()
        {
            InitializeComponent();
            channel = new Api();
            materialSkinManager = MaterialSkinManager.Instance;
            materialSkinManager.AddFormToManage(this);
            materialSkinManager.Theme = MaterialSkinManager.Themes.LIGHT;
            materialSkinManager.ColorScheme = new ColorScheme(Primary.BlueGrey800, Primary.BlueGrey900, Primary.BlueGrey500, Accent.LightBlue200, TextShade.WHITE);
            initform();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            btn_connect.BackColor = Color.Orange;
            tbox_IP.Text = "10.0.0.100";
            rbtn_TcpIp.Checked = true;
            FrmTips.ShowTipsError(this, "欢迎使用,请首先连接控制器");
        }
        private void initform()
        {
            tbox_ACC.Enabled = false;
            tbox_VEL.Enabled = false;
            tbox_DEC.Enabled = false;
            tbox_JERK.Enabled = false;
            tbox_JOGspeed.Enabled = false;
            tbox_KDEC.Enabled = false;
            tbox_position_dis.Enabled = false;
            tbox_Terminal.Enabled = false;
            cbox_useJOG.Enabled = false;
            btn_enable.AutoSize = false;
            btn_enable.Size = new Size(66, 25);
            btn_disable.AutoSize = false;
            btn_disable.Size = new Size(66, 25);
            btn_JOGNE.AutoSize = false;
            btn_JOGNE.Size = new Size(66, 23);
            btn_JOGRE.AutoSize = false;
            btn_JOGRE.Size = new Size(66, 23);
            btn_save.AutoSize = false;
            btn_save.Size = new Size(66, 23);
            btn_send.AutoSize = false;
            btn_send.Size = new Size(66, 23);
            btn_set0.AutoSize = false;
            btn_set0.Size = new Size(200, 23);
            btn_clear.AutoSize = false;
            btn_clear.Size = new Size(66, 23);
            rbtn_TcpIp.AutoSize = false;
            rbtn_TcpIp.Size = new Size(69, 23);
            rbtn_sim.AutoSize = false;
            rbtn_sim.Size = new Size(69, 23);
            Enable_baidu.AutoSize = false;
            Enable_baidu.Size = new Size(120, 23);

            btn_abposition.AutoSize = false;
            btn_abposition.Size = new Size(200, 23);
            btn_NEposition.AutoSize = false;
            btn_NEposition.Size = new Size(66, 23);
            btn_positive.AutoSize = false;
            btn_positive.Size = new Size(66, 23);

            tbox_VEL.Tag = 0;
            tbox_ACC.Tag = 1;
            tbox_DEC.Tag = 2;
            tbox_KDEC.Tag = 3;
            tbox_JERK.Tag = 4;


        }
        private void InitFormAfter()
        {
            tbox_ACC.Enabled = true;
            tbox_VEL.Enabled = true;
            tbox_DEC.Enabled = true;
            tbox_JERK.Enabled = true;
            tbox_JOGspeed.Enabled = true;
            tbox_KDEC.Enabled = true;
            tbox_position_dis.Enabled = true;
            tbox_Terminal.Enabled = true;
            cbox_useJOG.Enabled = true;

        }
        private void rbtn_sim_CheckedChanged(object sender, EventArgs e)
        {
            tbox_IP.Enabled = false;
        }
        private void rbtn_TcpIp_CheckedChanged(object sender, EventArgs e)
        {
            tbox_IP.Enabled = true;
        }
        private void btn_connect_BtnClick(object sender, EventArgs e)
        {
            try
            {
                if (!channel.IsConnected)
                {
                    if (rbtn_TcpIp.Checked)
                    {
                        channel.OpenCommEthernetTCP(tbox_IP.Text, 701);
                    }
                    else if (rbtn_sim.Checked)
                    {
                        channel.OpenCommSimulator();
                    }
                    btn_connect.Text = "断开连接";
                    materialSkinManager.ColorScheme = new ColorScheme(Primary.Indigo500, Primary.Indigo700, Primary.Indigo100, Accent.Pink200, TextShade.WHITE);
                    m_axis_count = Convert.ToInt32(channel.GetAxesCount());
                    m_arrAxisList = new Axis[m_axis_count + 1];
                    for (int i = 0; i < m_axis_count; i++)
                    {
                        cbBox_enable.Items.Add(i.ToString());
                        m_arrAxisList[i] = (Axis)i;
                    }
                    m_arrAxisList[m_axis_count] = Axis.ACSC_NONE;

                    Formnewset();

                    cbBox_enable.SelectedIndex = 0;
                    btn_enable.Enabled = true;
                    btn_disable.Enabled = true;

                    time_Update.Interval = 500;
                    time_Update.Enabled = true;
                    InitFormAfter();
                    dynamic_creatlabel();
                }
                else if (btn_connect.Text == "断开连接")
                {
                    channel.CloseComm();
                    btn_connect.Text = "连接";
                    btn_connect.ForeColor = Color.FromArgb(255, 77, 58);
                    time_Update.Enabled = false;
                }
            }
            catch (ACSException EX)
            {
                if (Enable_baidu.Checked)
                {
                    string args = EX.Message;
                    string reply = TransAPI(args);
                    MessageBox.Show(reply, "连接错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(EX.Message, "连接错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void Formnewset()
        {

        }
        //动态创建限位
        private void dynamic_creatlabel()
        {
            m_lblFatult = new Label[m_axis_count];
            for (int i = 0; i < m_axis_count; i++)
            {
                m_lblFatult[i] = new Label();
                m_lblFatult[i].Size = new Size(17, 12);
                m_lblFatult[i].Location = new Point(61 + i * 19, 24);
                m_lblFatult[i].Image = null;
                m_lblFatult[i].Name = i.ToString();
                m_lblFatult[i].Text = i.ToString();
                gbox_fault.Controls.Add(m_lblFatult[i]);
            }
            m_lblLeftLimit = new Label[m_axis_count];
            for (int i = 0; i < m_axis_count; i++)
            {
                m_lblLeftLimit[i] = new Label();
                m_lblLeftLimit[i].Size = new Size(19, 17);
                m_lblLeftLimit[i].Location = new Point(56 + i * 19, 50);
                m_lblLeftLimit[i].Image = Properties.Resources.Off;
                m_lblLeftLimit[i].Name = "lblLL" + i.ToString();
                gbox_fault.Controls.Add(m_lblLeftLimit[i]);
            }
            m_lblRightLimit = new Label[m_axis_count];
            for (int i = 0; i < m_axis_count; i++)
            {
                m_lblRightLimit[i] = new Label();
                m_lblRightLimit[i].Size = new Size(19, 17);
                m_lblRightLimit[i].Location = new Point(56 + i * 19, 75);
                m_lblRightLimit[i].Image = Properties.Resources.Off;
                m_lblRightLimit[i].Name = "lblRL" + i.ToString();
                gbox_fault.Controls.Add(m_lblRightLimit[i]);
            }
        }
        //开关使能
        private void btn_enable_BtnClick(object sender, EventArgs e)
        {
            if (!channel.IsConnected) { return; }
            channel.Enable((Axis)cbBox_enable.SelectedIndex);
        }
        private void btn_disable_BtnClick(object sender, EventArgs e)
        {
            if (!channel.IsConnected) { return; }
            channel.Disable((Axis)cbBox_enable.SelectedIndex);
        }
        #endregion
        #region 限位状态、运动参数获取
        //获取运动参数
        private void UpdateMotionProfile()
        {
            if (!channel.IsConnected) { return; }
            tbox_VEL.Text = channel.GetVelocity((Axis)cbBox_enable.SelectedIndex).ToString();
            tbox_ACC.Text = channel.GetAcceleration((Axis)cbBox_enable.SelectedIndex).ToString();
            tbox_DEC.Text = channel.GetDeceleration((Axis)cbBox_enable.SelectedIndex).ToString();
            tbox_KDEC.Text = channel.GetKillDeceleration((Axis)cbBox_enable.SelectedIndex).ToString();
            tbox_JERK.Text = channel.GetJerk((Axis)cbBox_enable.SelectedIndex).ToString();
        }
        private void cbBox_enable_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateProfile();
        }
        private void UpdateProfile()
        {
            if (!channel.IsConnected) { return; }
            tbox_VEL.Text = channel.GetVelocity((Axis)cbBox_enable.SelectedIndex).ToString();
            tbox_ACC.Text = channel.GetAcceleration((Axis)cbBox_enable.SelectedIndex).ToString();
            tbox_DEC.Text = channel.GetDeceleration((Axis)cbBox_enable.SelectedIndex).ToString();
            tbox_KDEC.Text = channel.GetKillDeceleration((Axis)cbBox_enable.SelectedIndex).ToString();
            tbox_JERK.Text = channel.GetJerk((Axis)cbBox_enable.SelectedIndex).ToString();
        }
        //更新限位、位置参数
        private void time_Update_Tick(object sender, EventArgs e)
        {
            //获取当前选中的轴
            int axis_NO = cbBox_enable.SelectedIndex;
            if (!channel.IsConnected) { return; }
            try
            {
                m_nMotorState = channel.GetMotorState((Axis)axis_NO);

                m_PE = (double)channel.ReadVariable("PE", ProgramBuffer.ACSC_NONE, axis_NO, axis_NO);
                //获取当前状态
                if ((m_nMotorState & MotorStates.ACSC_MST_MOVE) != 0) LED_moveing.Image = Properties.Resources.On; else LED_moveing.Image = Properties.Resources.Off;
                if ((m_nMotorState & MotorStates.ACSC_MST_ACC) != 0) LED_ACCing.Image = Properties.Resources.On; else LED_ACCing.Image = Properties.Resources.Off;
                if ((m_nMotorState & MotorStates.ACSC_MST_INPOS) != 0) LED_inposition.Image = Properties.Resources.On; else LED_inposition.Image = Properties.Resources.Off;
                if ((m_nMotorState & MotorStates.ACSC_MST_ENABLE) != 0) LED_enable.Image = Properties.Resources.On; else LED_enable.Image = Properties.Resources.Off;


                //获取当前位置
                tbox_RPOS.Text = string.Format("{0:0.000}", channel.GetRPosition((Axis)axis_NO));
                tbox_FPOS.Text = string.Format("{0:0.000}", channel.GetFPosition((Axis)axis_NO));
                tbox_FVEL.Text = string.Format("{0:0.000}", channel.GetFVelocity((Axis)axis_NO));
                tbox_PE.Text = string.Format("{0:0.000}", m_PE);
                //获取限位状态
                m_objReadVar = channel.ReadVariableAsVector("FAULT", ProgramBuffer.ACSC_NONE, 0, m_axis_count - 1, -1, -1);
                if (m_objReadVar != null)
                {
                    m_arrReadVector = m_objReadVar as Array;
                    if (m_arrReadVector != null)
                    {
                        for (int i = 0; i < m_axis_count; i++)
                        {
                            UpdateLimitState(i, (int)m_arrReadVector.GetValue(i));
                        }
                    }
                }
            }
            catch (ACSException EX)
            {
                if (Enable_baidu.Checked)
                {
                    string args = EX.Message;
                    string reply = TransAPI(args);
                    MessageBox.Show(reply, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(EX.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
        }
        // 更新限位状态
        private void UpdateLimitState(int axisNo, int fault)
        {
            if (axisNo < MAX_UI_LIMIT_CNT)
            {
                if ((fault & (int)SafetyControlMasks.ACSC_SAFETY_LL) != 0) m_lblLeftLimit[axisNo].Image = Properties.Resources.Error; else m_lblLeftLimit[axisNo].Image = Properties.Resources.Off;
                if ((fault & (int)SafetyControlMasks.ACSC_SAFETY_RL) != 0) m_lblRightLimit[axisNo].Image = Properties.Resources.Error; else m_lblRightLimit[axisNo].Image = Properties.Resources.Off;
            }
        }
        #endregion
        # region 设置当前位置为0
        private void btn_set0_BtnClick(object sender, EventArgs e)
        {
            if (!channel.IsConnected) { return; }
            //设置当前位置为0
            channel.SetFPosition((Axis)cbBox_enable.SelectedIndex, 0);
        }
        #endregion
        #region JOG运动
        private void btn_JOGNE_MouseDown(object sender, MouseEventArgs e)
        {
            if (!channel.IsConnected) { return; }
            time_Update.Interval = 50;
            double JOGNE_SPEED = 0.0F;
            try
            {
                if (cbox_useJOG.Checked)
                {
                    JOGNE_SPEED = Convert.ToDouble(tbox_JOGspeed.Text);
                    if (JOGNE_SPEED > 0) { JOGNE_SPEED = JOGNE_SPEED * (-1); }
                    channel.Jog(MotionFlags.ACSC_AMF_VELOCITY, (Axis)cbBox_enable.SelectedIndex, JOGNE_SPEED);
                }
                else
                {
                    channel.Jog(0, (Axis)cbBox_enable.SelectedIndex, (Double)GlobalDirection.ACSC_NEGATIVE_DIRECTION);
                }
            }
            catch (ACSException EX)
            {
                if (Enable_baidu.Checked)
                {
                    string args = EX.Message;
                    string reply = TransAPI(args);
                    MessageBox.Show(reply, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(EX.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void btn_JOGRE_MouseDown(object sender, MouseEventArgs e)
        {
            if (!channel.IsConnected) { return; }
            time_Update.Interval = 50;
            double JOGNE_SPEED = 0.0F;
            try
            {
                if (cbox_useJOG.Checked)
                {
                    JOGNE_SPEED = Convert.ToDouble(tbox_JOGspeed.Text);
                    if (JOGNE_SPEED < 0) { JOGNE_SPEED = JOGNE_SPEED * (-1); }
                    channel.Jog(MotionFlags.ACSC_AMF_VELOCITY, (Axis)cbBox_enable.SelectedIndex, JOGNE_SPEED);
                }
                else
                {
                    channel.Jog(0, (Axis)cbBox_enable.SelectedIndex, (Double)GlobalDirection.ACSC_POSITIVE_DIRECTION);
                }
            }
            catch (ACSException EX)
            {
                if (Enable_baidu.Checked)
                {
                    string args = EX.Message;
                    string reply = TransAPI(args);
                    MessageBox.Show(reply, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(EX.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void btn_JOGRE_MouseUp(object sender, MouseEventArgs e)
        {
            if (!channel.IsConnected) { return; }
            channel.Halt((Axis)cbBox_enable.SelectedIndex);
            time_Update.Interval = 500;
        }
        private void btn_JOGNE_MouseUp(object sender, MouseEventArgs e)
        {
            if (!channel.IsConnected) { return; }
            channel.Halt((Axis)cbBox_enable.SelectedIndex);
            time_Update.Interval = 500;
        }
        #endregion
        #region 通讯终端
        private void btn_send_BtnClick(object sender, EventArgs e)
        {
            if (!channel.IsConnected) { return; }
            initTerminal();
        }
        private void tbox_Terminal_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                initTerminal();
            }
        }
        private void initTerminal()
        {
            try
            {
                string cmd = tbox_Terminal.Text.ToUpper();
                if (Enable_baidu.Checked)
                {
                    string args = channel.Transaction(cmd);
                    string reply = TransAPI(args);
                    rbox_terminal.Text += cmd + "\n";
                    rbox_terminal.Text += reply + "\n" + ":" + "\n";
                }
                else
                {
                    rbox_terminal.Text += cmd + "\n";
                    rbox_terminal.Text += channel.Transaction(cmd) + ":"+ "\n";
                }
            }
            catch (ACSException EX)
            {
                if (Enable_baidu.Checked)
                {
                    string args = EX.Message;
                    string reply = TransAPI(args);
                    MessageBox.Show(reply, "通讯终端错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(EX.Message, "通讯终端错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                rbox_terminal.Text = "错误代码为：" + Convert.ToString(EX.ErrorCode) + "\n";
            }
        }
        private void btn_clear_BtnClick(object sender, EventArgs e)
        {
            rbox_terminal.Text = "";
        }
        private void btn_save_BtnClick(object sender, EventArgs e)
        {
            if (!channel.IsConnected) { return; }
            SaveFileDialog file = new SaveFileDialog();
            file.Title = "通讯终端输出结果保存";
            file.Filter = "文本文件|*.txt|全部文件|*.*";
            file.RestoreDirectory = true;//是否记录上次的路径
            file.FileName = tbox_Terminal.Text;
            if (file.ShowDialog() == DialogResult.OK)
            {
                string Path = file.FileName;
                File.WriteAllText(Path, rbox_terminal.Text);
            }
        }
        #endregion
        #region 百度翻译
        static string TransAPI(string args)
        {
            // 原文
            string q = args;
            // 源语言
            string from = "auto";
            // 目标语言
            string to = "zh";
            // 改成您的APP ID
            string appId = "20201203000635687";
            Random rd = new Random();
            string salt = rd.Next(100000).ToString();
            // 改成您的密钥
            string secretKey = "l4ILmi5BEkVCKkA_PtGk";
            string sign = EncryptString(appId + q + salt + secretKey);
            string url = "http://api.fanyi.baidu.com/api/trans/vip/translate?";
            url += "q=" + HttpUtility.UrlEncode(q);
            url += "&from=" + from;
            url += "&to=" + to;
            url += "&appid=" + appId;
            url += "&salt=" + salt;
            url += "&sign=" + sign;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            request.Method = "GET";
            request.ContentType = "text/html;charset=UTF-8";
            request.UserAgent = null;
            request.Timeout = 60000;
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            Stream myResponseStream = response.GetResponseStream();
            StreamReader myStreamReader = new StreamReader(myResponseStream, Encoding.GetEncoding("utf-8"));

            JsonTextReader jsonTextReader = new JsonTextReader(myStreamReader);
            JsonSerializer serializer = new JsonSerializer();
            var r = serializer.Deserialize<TranClass>(jsonTextReader);
            return r.Trans_result[0].dst;
        }
        // 计算MD5值
        public static string EncryptString(string str)
        {
            MD5 md5 = MD5.Create();
            // 将字符串转换成字节数组
            byte[] byteOld = Encoding.UTF8.GetBytes(str);
            // 调用加密方法
            byte[] byteNew = md5.ComputeHash(byteOld);
            // 将加密结果转换为字符串
            StringBuilder sb = new StringBuilder();
            foreach (byte b in byteNew)
            {
                // 将字节转换成16进制表示的字符串，
                sb.Append(b.ToString("x2"));
            }
            // 返回加密的字符串
            return sb.ToString();
        }
        #endregion
        #region 界面转换
        private void ucBtnExt1_BtnClick(object sender, EventArgs e)
        {
            Form_Guide fm = new Form_Guide();
            fm.Show();
            this.Hide();
        }

        private void winMain_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }


        #endregion
        #region 提示
        private void tbox_Terminal_MouseClick(object sender, MouseEventArgs e)
        {
            FrmTips.ShowTipsWarning(this, "输出多行字符时请关闭翻译，如#SI、#EtherCAT等");
        }

        private void Enable_baidu_CheckedChanged(object sender, EventArgs e)
        {
            FrmTips.ShowTipsWarning(this, "仅在联网时可用");
        }

        #endregion
        #region 停止运动
        private void btn_STOP_Click(object sender, EventArgs e)
        {
            if (!channel.IsConnected) { return; }
            channel.KillAll();
        }
        #endregion
        #region 改变参数
        private void TextBoxes_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                double lfTemp = 0.0f;
                Control textBox = sender as Control;
                if (textBox != null)
                {
                    // Allow numbers (0 ~ 9), . (DOT), Backspace
                    if ((e.KeyChar >= 0x30 && e.KeyChar <= 0x39) || e.KeyChar == 0x2E || e.KeyChar == 0x08 || e.KeyChar == (char)Keys.Return || e.KeyChar == (char)Keys.Enter)
                    {
                        if ((e.KeyChar == 0x2E) && (textBox.Text.Contains(Convert.ToString(0x2E)))) e.KeyChar = (char)0x00;
                        if (e.KeyChar == (char)Keys.Return || e.KeyChar == (char)Keys.Enter)
                        {
                            e.Handled = true;

                            lfTemp = Convert.ToDouble(textBox.Text.Trim());
                            int g = (int)textBox.Tag;
                            switch (g)
                            {
                                // Immediately change value (On the fly) : SetVelocityImm() 
                                // Affect next motion	: SetVelocity()	

                                case 0: channel.SetVelocityImm((Axis)cbBox_enable.SelectedIndex, lfTemp); break;
                                case 1: channel.SetAccelerationImm((Axis)cbBox_enable.SelectedIndex, lfTemp); break;
                                case 2: channel.SetDecelerationImm((Axis)cbBox_enable.SelectedIndex, lfTemp); break;
                                case 3: channel.SetKillDecelerationImm((Axis)cbBox_enable.SelectedIndex, lfTemp); break;
                                case 4: channel.SetJerkImm((Axis)cbBox_enable.SelectedIndex, lfTemp); break;
                            }
                            //textBox.SelectAll();
                        }
                    }
                    else e.KeyChar = (char)0x00;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("TextBoxes_KeyPress() Error\n" + ex.ToString());
            }
        }
        private void cbBox_enable_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            UpdateMotionProfile();
        }
        private void TextBoxes_Enter(object sender, EventArgs e)
        {
            try
            {
                TextBox textBox = sender as TextBox;
                if (textBox != null) textBox.SelectAll();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("TextBoxes_Enter() Error\n" + ex.ToString());
            }
        }

        private void TextBoxes_Leave(object sender, EventArgs e)
        {
            try
            {
                double lfTemp = 0.0f;

                TextBox textBox = sender as TextBox;
                if (textBox == null) return;

                lfTemp = Convert.ToDouble(textBox.Text.Trim());
                int g = (int)textBox.Tag;
                switch (g)
                {
                    case 0: channel.SetVelocityImm((Axis)cbBox_enable.SelectedIndex, lfTemp); break;
                    case 1: channel.SetAccelerationImm((Axis)cbBox_enable.SelectedIndex, lfTemp); break;
                    case 2: channel.SetDecelerationImm((Axis)cbBox_enable.SelectedIndex, lfTemp); break;
                    case 3: channel.SetKillDecelerationImm((Axis)cbBox_enable.SelectedIndex, lfTemp); break;
                    case 4: channel.SetJerkImm((Axis)cbBox_enable.SelectedIndex, lfTemp); break;
                }

                textBox.SelectAll();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("TextBoxes_Leave() Error\n" + ex.ToString());
            }
        }

        #endregion
        #region 绝对运动
        private void btn_abposition_Click(object sender, EventArgs e)
        {
            if (!channel.IsConnected) { return; }
            double lfTargetPos = 0.0f;
            try
            {
                if (tbox_position_dis.Text.Length > 0)
                {
                    lfTargetPos = Convert.ToDouble(tbox_position_dis.Text);
                    channel.ToPoint(0, (Axis)cbBox_enable.SelectedIndex, lfTargetPos);
                }
            }
            catch (Exception ex)
            {
                if (Enable_baidu.Checked)
                {
                    string args = ex.Message;
                    string reply = TransAPI(args);
                    MessageBox.Show(reply, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        #endregion
        #region 绝对位置运动
        private void btn_NEposition_Click(object sender, EventArgs e)
        {
            if (!channel.IsConnected) { return; }
            double lfTargetPos = 0.0f;
            try
            {
                if (tbox_position_dis.Text.Length > 0)
                {
                    lfTargetPos = Convert.ToDouble(tbox_position_dis.Text);
                    if (lfTargetPos > 0) lfTargetPos = lfTargetPos * (-1);
                    channel.ToPoint(MotionFlags.ACSC_AMF_RELATIVE, (Axis)cbBox_enable.SelectedIndex, lfTargetPos);
                }
            }
            catch (Exception ex)
            {
                if (Enable_baidu.Checked)
                {
                    string args = ex.Message;
                    string reply = TransAPI(args);
                    MessageBox.Show(reply, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btn_positive_Click(object sender, EventArgs e)
        {
            if (!channel.IsConnected) { return; }
            double lfTargetPos = 0.0f;
            try
            {
                if (tbox_position_dis.Text.Length > 0)
                {
                    lfTargetPos = Convert.ToDouble(tbox_position_dis.Text);
                    if (lfTargetPos < 0) lfTargetPos = lfTargetPos * (-1);
                    channel.ToPoint(MotionFlags.ACSC_AMF_RELATIVE, (Axis)cbBox_enable.SelectedIndex, lfTargetPos);
                }
            }
            catch (Exception ex)
            {
                if (Enable_baidu.Checked)
                {
                    string args = ex.Message;
                    string reply = TransAPI(args);
                    MessageBox.Show(reply, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        #endregion
        #region 清除报错
        private void btn_clearFault_Click(object sender, EventArgs e)
        {
            if (!channel.IsConnected) { return; }
            for (int i = 0; i < m_arrAxisList.Length - 1; i++)
            {
                channel.FaultClear(m_arrAxisList[i]);
            }
        }
        #endregion
        #region  往返运动
        private void btn_readA_Click(object sender, EventArgs e)
        {
            if (!channel.IsConnected) { return; }
            tbox_APosition.Text = Convert.ToString(channel.GetFPosition((Axis)cbBox_enable.SelectedIndex));
        }
        private void btn_readB_Click(object sender, EventArgs e)
        {
            if (!channel.IsConnected) { return; }
            tbox_BPosition.Text = Convert.ToString(channel.GetFPosition((Axis)cbBox_enable.SelectedIndex));
        }
        private void btn_statABMotion_Click(object sender, EventArgs e)
        {
            string Axis = cbBox_enable.SelectedIndex.ToString();
            string dwell = tbox_delayTime.Text;
            string APositon = tbox_APosition.Text;
            string BPositon = tbox_BPosition.Text;
            try
            {
                string cmd = "MPTP/C "+ Axis + ","+ dwell;
                string args = channel.Transaction(cmd);
                rbox_terminal.Text += args + "\n";

                 cmd = "POINT " + Axis + "," + APositon;
                 args = channel.Transaction(cmd);
                rbox_terminal.Text += args + "\n";

                 cmd = "POINT " + Axis + "," + BPositon;
                 args = channel.Transaction(cmd);
                rbox_terminal.Text += args + "\n";

                 cmd = "ENDS "+Axis;
                 args = channel.Transaction(cmd);
                rbox_terminal.Text += args + "\n";
            }
            catch (ACSException EX)
            {
                if (Enable_baidu.Checked)
                {
                    string args = EX.Message;
                    string reply = TransAPI(args);
                    MessageBox.Show(reply, "往返运动错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(EX.Message, "往返运动错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                rbox_terminal.Text = "错误代码为：" + Convert.ToString(EX.ErrorCode) + "\n";
            }
        }
        #endregion

    }
}
namespace BDTranslate.Models
{
    public class TranClass
    {
        public string From { get; set; }
        public string To { get; set; }
        public List<Trans_result> Trans_result { get; set; }
    }
    public class Trans_result
    {
        public string src { get; set; }
        public string dst { get; set; }
    }
}

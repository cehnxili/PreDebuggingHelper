﻿
namespace 预调试助手
{
    partial class Form_Guide
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Guide));
            this.graphicalOverlayComponent1 = new HZH_Controls.Controls.GraphicalOverlayComponent(this.components);
            this.btn_skip = new MaterialSkin.Controls.MaterialFlatButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tabControl1 = new MaterialSkin.Controls.MaterialTabControl();
            this.tabPage_lead = new System.Windows.Forms.TabPage();
            this.panel_pic = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.treeViewEx1 = new HZH_Controls.Controls.TreeViewEx();
            this.tabPage_setup = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.picPoint21 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.picPoint23 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.picPoint22 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.picPoint13 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.picPoint12 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.picPoint11 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.materialTabSelector1 = new MaterialSkin.Controls.MaterialTabSelector();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtPoint21 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.txtPoint23 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.txtPoint22 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.txtPoint13 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.txtPoint12 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.txtPoint11 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.treeNode21 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.treeNode23 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.treeNode22 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.treeNode13 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.treeNode12 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.treeNode1 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.treeNode11 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.treeNode2 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.tabPage_Gcode = new System.Windows.Forms.TabPage();
            this.btn_change = new MaterialSkin.Controls.MaterialRaisedButton();
            this.btn_Gsave = new MaterialSkin.Controls.MaterialRaisedButton();
            this.Gcodetext = new System.Windows.Forms.RichTextBox();
            this.btn_downset = new MaterialSkin.Controls.MaterialRaisedButton();
            this.panel1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage_lead.SuspendLayout();
            this.panel_pic.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage_setup.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.tabPage_Gcode.SuspendLayout();
            this.SuspendLayout();
            // 
            // graphicalOverlayComponent1
            // 
            this.graphicalOverlayComponent1.Owner = null;
            // 
            // btn_skip
            // 
            this.btn_skip.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_skip.AutoSize = true;
            this.btn_skip.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_skip.BackColor = System.Drawing.Color.White;
            this.btn_skip.Depth = 0;
            this.btn_skip.Icon = null;
            this.btn_skip.Location = new System.Drawing.Point(946, 562);
            this.btn_skip.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.btn_skip.MouseState = MaterialSkin.MouseState.HOVER;
            this.btn_skip.Name = "btn_skip";
            this.btn_skip.Primary = false;
            this.btn_skip.Size = new System.Drawing.Size(51, 36);
            this.btn_skip.TabIndex = 5;
            this.btn_skip.Text = "跳过";
            this.btn_skip.UseVisualStyleBackColor = false;
            this.btn_skip.Click += new System.EventHandler(this.btn_skip_Click_1);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.tabControl1);
            this.panel1.Location = new System.Drawing.Point(0, 64);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1000, 536);
            this.panel1.TabIndex = 6;
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage_lead);
            this.tabControl1.Controls.Add(this.tabPage_Gcode);
            this.tabControl1.Controls.Add(this.tabPage_setup);
            this.tabControl1.Depth = 0;
            this.tabControl1.Location = new System.Drawing.Point(3, 34);
            this.tabControl1.MouseState = MaterialSkin.MouseState.HOVER;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(997, 502);
            this.tabControl1.TabIndex = 8;
            // 
            // tabPage_lead
            // 
            this.tabPage_lead.Controls.Add(this.panel_pic);
            this.tabPage_lead.Controls.Add(this.treeViewEx1);
            this.tabPage_lead.Location = new System.Drawing.Point(4, 22);
            this.tabPage_lead.Name = "tabPage_lead";
            this.tabPage_lead.Size = new System.Drawing.Size(989, 476);
            this.tabPage_lead.TabIndex = 2;
            this.tabPage_lead.Text = "向导";
            this.tabPage_lead.UseVisualStyleBackColor = true;
            // 
            // panel_pic
            // 
            this.panel_pic.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel_pic.BackColor = System.Drawing.Color.Transparent;
            this.panel_pic.Controls.Add(this.pictureBox1);
            this.panel_pic.Location = new System.Drawing.Point(200, 0);
            this.panel_pic.Name = "panel_pic";
            this.panel_pic.Size = new System.Drawing.Size(789, 476);
            this.panel_pic.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Location = new System.Drawing.Point(-3, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(790, 476);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // treeViewEx1
            // 
            this.treeViewEx1.BackColor = System.Drawing.Color.White;
            this.treeViewEx1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.treeViewEx1.DrawMode = System.Windows.Forms.TreeViewDrawMode.OwnerDrawAll;
            this.treeViewEx1.Font = new System.Drawing.Font("阿里巴巴普惠体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.treeViewEx1.FullRowSelect = true;
            this.treeViewEx1.HideSelection = false;
            this.treeViewEx1.IsShowByCustomModel = true;
            this.treeViewEx1.IsShowTip = false;
            this.treeViewEx1.ItemHeight = 50;
            this.treeViewEx1.Location = new System.Drawing.Point(0, 0);
            this.treeViewEx1.LstTips = ((System.Collections.Generic.Dictionary<string, string>)(resources.GetObject("treeViewEx1.LstTips")));
            this.treeViewEx1.Name = "treeViewEx1";
            this.treeViewEx1.NodeBackgroundColor = System.Drawing.Color.White;
            this.treeViewEx1.NodeDownPic = ((System.Drawing.Image)(resources.GetObject("treeViewEx1.NodeDownPic")));
            this.treeViewEx1.NodeForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(62)))), ((int)(((byte)(62)))));
            this.treeViewEx1.NodeHeight = 50;
            this.treeViewEx1.NodeIsShowSplitLine = false;
            this.treeViewEx1.NodeSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(71)))), ((int)(((byte)(79)))));
            this.treeViewEx1.NodeSelectedForeColor = System.Drawing.Color.White;
            this.treeViewEx1.NodeSplitLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(232)))), ((int)(((byte)(232)))));
            this.treeViewEx1.NodeUpPic = ((System.Drawing.Image)(resources.GetObject("treeViewEx1.NodeUpPic")));
            this.treeViewEx1.ParentNodeCanSelect = true;
            this.treeViewEx1.ShowLines = false;
            this.treeViewEx1.ShowPlusMinus = false;
            this.treeViewEx1.ShowRootLines = false;
            this.treeViewEx1.Size = new System.Drawing.Size(194, 491);
            this.treeViewEx1.TabIndex = 0;
            this.treeViewEx1.TipFont = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.treeViewEx1.TipImage = ((System.Drawing.Image)(resources.GetObject("treeViewEx1.TipImage")));
            this.treeViewEx1.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.treeViewEx1_NodeMouseClick);
            // 
            // tabPage_setup
            // 
            this.tabPage_setup.Controls.Add(this.btn_downset);
            this.tabPage_setup.Controls.Add(this.pictureBox2);
            this.tabPage_setup.Controls.Add(this.groupBox3);
            this.tabPage_setup.Controls.Add(this.groupBox2);
            this.tabPage_setup.Controls.Add(this.groupBox1);
            this.tabPage_setup.Location = new System.Drawing.Point(4, 22);
            this.tabPage_setup.Name = "tabPage_setup";
            this.tabPage_setup.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_setup.Size = new System.Drawing.Size(989, 476);
            this.tabPage_setup.TabIndex = 1;
            this.tabPage_setup.Text = "软件配置";
            this.tabPage_setup.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.picPoint21);
            this.groupBox1.Controls.Add(this.picPoint23);
            this.groupBox1.Controls.Add(this.picPoint22);
            this.groupBox1.Controls.Add(this.picPoint13);
            this.groupBox1.Controls.Add(this.picPoint12);
            this.groupBox1.Controls.Add(this.picPoint11);
            this.groupBox1.Location = new System.Drawing.Point(2, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(125, 470);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "图片名称配置";
            // 
            // picPoint21
            // 
            this.picPoint21.Depth = 0;
            this.picPoint21.Hint = "子节点4名称";
            this.picPoint21.Location = new System.Drawing.Point(6, 269);
            this.picPoint21.MaxLength = 32767;
            this.picPoint21.MouseState = MaterialSkin.MouseState.HOVER;
            this.picPoint21.Name = "picPoint21";
            this.picPoint21.PasswordChar = '\0';
            this.picPoint21.SelectedText = "";
            this.picPoint21.SelectionLength = 0;
            this.picPoint21.SelectionStart = 0;
            this.picPoint21.Size = new System.Drawing.Size(99, 23);
            this.picPoint21.TabIndex = 3;
            this.picPoint21.TabStop = false;
            this.picPoint21.UseSystemPasswordChar = false;
            // 
            // picPoint23
            // 
            this.picPoint23.Depth = 0;
            this.picPoint23.Hint = "子节点6名称";
            this.picPoint23.Location = new System.Drawing.Point(6, 433);
            this.picPoint23.MaxLength = 32767;
            this.picPoint23.MouseState = MaterialSkin.MouseState.HOVER;
            this.picPoint23.Name = "picPoint23";
            this.picPoint23.PasswordChar = '\0';
            this.picPoint23.SelectedText = "";
            this.picPoint23.SelectionLength = 0;
            this.picPoint23.SelectionStart = 0;
            this.picPoint23.Size = new System.Drawing.Size(99, 23);
            this.picPoint23.TabIndex = 5;
            this.picPoint23.TabStop = false;
            this.picPoint23.UseSystemPasswordChar = false;
            // 
            // picPoint22
            // 
            this.picPoint22.Depth = 0;
            this.picPoint22.Hint = "子节点5名称";
            this.picPoint22.Location = new System.Drawing.Point(6, 351);
            this.picPoint22.MaxLength = 32767;
            this.picPoint22.MouseState = MaterialSkin.MouseState.HOVER;
            this.picPoint22.Name = "picPoint22";
            this.picPoint22.PasswordChar = '\0';
            this.picPoint22.SelectedText = "";
            this.picPoint22.SelectionLength = 0;
            this.picPoint22.SelectionStart = 0;
            this.picPoint22.Size = new System.Drawing.Size(99, 23);
            this.picPoint22.TabIndex = 4;
            this.picPoint22.TabStop = false;
            this.picPoint22.UseSystemPasswordChar = false;
            // 
            // picPoint13
            // 
            this.picPoint13.Depth = 0;
            this.picPoint13.Hint = "子节点3名称";
            this.picPoint13.Location = new System.Drawing.Point(6, 187);
            this.picPoint13.MaxLength = 32767;
            this.picPoint13.MouseState = MaterialSkin.MouseState.HOVER;
            this.picPoint13.Name = "picPoint13";
            this.picPoint13.PasswordChar = '\0';
            this.picPoint13.SelectedText = "";
            this.picPoint13.SelectionLength = 0;
            this.picPoint13.SelectionStart = 0;
            this.picPoint13.Size = new System.Drawing.Size(99, 23);
            this.picPoint13.TabIndex = 2;
            this.picPoint13.TabStop = false;
            this.picPoint13.UseSystemPasswordChar = false;
            // 
            // picPoint12
            // 
            this.picPoint12.Depth = 0;
            this.picPoint12.Hint = "子节点2名称";
            this.picPoint12.Location = new System.Drawing.Point(6, 105);
            this.picPoint12.MaxLength = 32767;
            this.picPoint12.MouseState = MaterialSkin.MouseState.HOVER;
            this.picPoint12.Name = "picPoint12";
            this.picPoint12.PasswordChar = '\0';
            this.picPoint12.SelectedText = "";
            this.picPoint12.SelectionLength = 0;
            this.picPoint12.SelectionStart = 0;
            this.picPoint12.Size = new System.Drawing.Size(99, 23);
            this.picPoint12.TabIndex = 1;
            this.picPoint12.TabStop = false;
            this.picPoint12.UseSystemPasswordChar = false;
            // 
            // picPoint11
            // 
            this.picPoint11.Depth = 0;
            this.picPoint11.Hint = "子节点1名称";
            this.picPoint11.Location = new System.Drawing.Point(6, 23);
            this.picPoint11.MaxLength = 32767;
            this.picPoint11.MouseState = MaterialSkin.MouseState.HOVER;
            this.picPoint11.Name = "picPoint11";
            this.picPoint11.PasswordChar = '\0';
            this.picPoint11.SelectedText = "";
            this.picPoint11.SelectionLength = 0;
            this.picPoint11.SelectionStart = 0;
            this.picPoint11.Size = new System.Drawing.Size(99, 23);
            this.picPoint11.TabIndex = 0;
            this.picPoint11.TabStop = false;
            this.picPoint11.UseSystemPasswordChar = false;
            // 
            // materialTabSelector1
            // 
            this.materialTabSelector1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.materialTabSelector1.BaseTabControl = this.tabControl1;
            this.materialTabSelector1.Depth = 0;
            this.materialTabSelector1.Location = new System.Drawing.Point(0, 64);
            this.materialTabSelector1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialTabSelector1.Name = "materialTabSelector1";
            this.materialTabSelector1.Size = new System.Drawing.Size(1000, 35);
            this.materialTabSelector1.TabIndex = 7;
            this.materialTabSelector1.Text = "materialTabSelector1";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox2.BackColor = System.Drawing.Color.White;
            this.groupBox2.Controls.Add(this.txtPoint21);
            this.groupBox2.Controls.Add(this.txtPoint23);
            this.groupBox2.Controls.Add(this.txtPoint22);
            this.groupBox2.Controls.Add(this.txtPoint13);
            this.groupBox2.Controls.Add(this.txtPoint12);
            this.groupBox2.Controls.Add(this.txtPoint11);
            this.groupBox2.Location = new System.Drawing.Point(133, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(125, 470);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "文本名称配置";
            // 
            // txtPoint21
            // 
            this.txtPoint21.Depth = 0;
            this.txtPoint21.Hint = "子节点4名称";
            this.txtPoint21.Location = new System.Drawing.Point(6, 269);
            this.txtPoint21.MaxLength = 32767;
            this.txtPoint21.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtPoint21.Name = "txtPoint21";
            this.txtPoint21.PasswordChar = '\0';
            this.txtPoint21.SelectedText = "";
            this.txtPoint21.SelectionLength = 0;
            this.txtPoint21.SelectionStart = 0;
            this.txtPoint21.Size = new System.Drawing.Size(99, 23);
            this.txtPoint21.TabIndex = 3;
            this.txtPoint21.TabStop = false;
            this.txtPoint21.UseSystemPasswordChar = false;
            // 
            // txtPoint23
            // 
            this.txtPoint23.Depth = 0;
            this.txtPoint23.Hint = "子节点6名称";
            this.txtPoint23.Location = new System.Drawing.Point(6, 433);
            this.txtPoint23.MaxLength = 32767;
            this.txtPoint23.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtPoint23.Name = "txtPoint23";
            this.txtPoint23.PasswordChar = '\0';
            this.txtPoint23.SelectedText = "";
            this.txtPoint23.SelectionLength = 0;
            this.txtPoint23.SelectionStart = 0;
            this.txtPoint23.Size = new System.Drawing.Size(99, 23);
            this.txtPoint23.TabIndex = 5;
            this.txtPoint23.TabStop = false;
            this.txtPoint23.UseSystemPasswordChar = false;
            // 
            // txtPoint22
            // 
            this.txtPoint22.Depth = 0;
            this.txtPoint22.Hint = "子节点5名称";
            this.txtPoint22.Location = new System.Drawing.Point(6, 351);
            this.txtPoint22.MaxLength = 32767;
            this.txtPoint22.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtPoint22.Name = "txtPoint22";
            this.txtPoint22.PasswordChar = '\0';
            this.txtPoint22.SelectedText = "";
            this.txtPoint22.SelectionLength = 0;
            this.txtPoint22.SelectionStart = 0;
            this.txtPoint22.Size = new System.Drawing.Size(99, 23);
            this.txtPoint22.TabIndex = 4;
            this.txtPoint22.TabStop = false;
            this.txtPoint22.UseSystemPasswordChar = false;
            // 
            // txtPoint13
            // 
            this.txtPoint13.Depth = 0;
            this.txtPoint13.Hint = "子节点3名称";
            this.txtPoint13.Location = new System.Drawing.Point(6, 187);
            this.txtPoint13.MaxLength = 32767;
            this.txtPoint13.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtPoint13.Name = "txtPoint13";
            this.txtPoint13.PasswordChar = '\0';
            this.txtPoint13.SelectedText = "";
            this.txtPoint13.SelectionLength = 0;
            this.txtPoint13.SelectionStart = 0;
            this.txtPoint13.Size = new System.Drawing.Size(99, 23);
            this.txtPoint13.TabIndex = 2;
            this.txtPoint13.TabStop = false;
            this.txtPoint13.UseSystemPasswordChar = false;
            // 
            // txtPoint12
            // 
            this.txtPoint12.Depth = 0;
            this.txtPoint12.Hint = "子节点2名称";
            this.txtPoint12.Location = new System.Drawing.Point(6, 105);
            this.txtPoint12.MaxLength = 32767;
            this.txtPoint12.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtPoint12.Name = "txtPoint12";
            this.txtPoint12.PasswordChar = '\0';
            this.txtPoint12.SelectedText = "";
            this.txtPoint12.SelectionLength = 0;
            this.txtPoint12.SelectionStart = 0;
            this.txtPoint12.Size = new System.Drawing.Size(99, 23);
            this.txtPoint12.TabIndex = 1;
            this.txtPoint12.TabStop = false;
            this.txtPoint12.UseSystemPasswordChar = false;
            // 
            // txtPoint11
            // 
            this.txtPoint11.Depth = 0;
            this.txtPoint11.Hint = "子节点1名称";
            this.txtPoint11.Location = new System.Drawing.Point(6, 23);
            this.txtPoint11.MaxLength = 32767;
            this.txtPoint11.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtPoint11.Name = "txtPoint11";
            this.txtPoint11.PasswordChar = '\0';
            this.txtPoint11.SelectedText = "";
            this.txtPoint11.SelectionLength = 0;
            this.txtPoint11.SelectionStart = 0;
            this.txtPoint11.Size = new System.Drawing.Size(99, 23);
            this.txtPoint11.TabIndex = 0;
            this.txtPoint11.TabStop = false;
            this.txtPoint11.UseSystemPasswordChar = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox3.BackColor = System.Drawing.Color.White;
            this.groupBox3.Controls.Add(this.treeNode2);
            this.groupBox3.Controls.Add(this.treeNode11);
            this.groupBox3.Controls.Add(this.treeNode21);
            this.groupBox3.Controls.Add(this.treeNode23);
            this.groupBox3.Controls.Add(this.treeNode22);
            this.groupBox3.Controls.Add(this.treeNode13);
            this.groupBox3.Controls.Add(this.treeNode12);
            this.groupBox3.Controls.Add(this.treeNode1);
            this.groupBox3.Location = new System.Drawing.Point(264, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(125, 470);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "树节点名称配置";
            // 
            // treeNode21
            // 
            this.treeNode21.Depth = 0;
            this.treeNode21.Hint = "子节点4名称";
            this.treeNode21.Location = new System.Drawing.Point(13, 313);
            this.treeNode21.MaxLength = 32767;
            this.treeNode21.MouseState = MaterialSkin.MouseState.HOVER;
            this.treeNode21.Name = "treeNode21";
            this.treeNode21.PasswordChar = '\0';
            this.treeNode21.SelectedText = "";
            this.treeNode21.SelectionLength = 0;
            this.treeNode21.SelectionStart = 0;
            this.treeNode21.Size = new System.Drawing.Size(99, 23);
            this.treeNode21.TabIndex = 3;
            this.treeNode21.TabStop = false;
            this.treeNode21.UseSystemPasswordChar = false;
            // 
            // treeNode23
            // 
            this.treeNode23.Depth = 0;
            this.treeNode23.Hint = "子节点6名称";
            this.treeNode23.Location = new System.Drawing.Point(13, 429);
            this.treeNode23.MaxLength = 32767;
            this.treeNode23.MouseState = MaterialSkin.MouseState.HOVER;
            this.treeNode23.Name = "treeNode23";
            this.treeNode23.PasswordChar = '\0';
            this.treeNode23.SelectedText = "";
            this.treeNode23.SelectionLength = 0;
            this.treeNode23.SelectionStart = 0;
            this.treeNode23.Size = new System.Drawing.Size(99, 23);
            this.treeNode23.TabIndex = 5;
            this.treeNode23.TabStop = false;
            this.treeNode23.UseSystemPasswordChar = false;
            // 
            // treeNode22
            // 
            this.treeNode22.Depth = 0;
            this.treeNode22.Hint = "子节点5名称";
            this.treeNode22.Location = new System.Drawing.Point(13, 371);
            this.treeNode22.MaxLength = 32767;
            this.treeNode22.MouseState = MaterialSkin.MouseState.HOVER;
            this.treeNode22.Name = "treeNode22";
            this.treeNode22.PasswordChar = '\0';
            this.treeNode22.SelectedText = "";
            this.treeNode22.SelectionLength = 0;
            this.treeNode22.SelectionStart = 0;
            this.treeNode22.Size = new System.Drawing.Size(99, 23);
            this.treeNode22.TabIndex = 4;
            this.treeNode22.TabStop = false;
            this.treeNode22.UseSystemPasswordChar = false;
            // 
            // treeNode13
            // 
            this.treeNode13.Depth = 0;
            this.treeNode13.Hint = "子节点3名称";
            this.treeNode13.Location = new System.Drawing.Point(13, 197);
            this.treeNode13.MaxLength = 32767;
            this.treeNode13.MouseState = MaterialSkin.MouseState.HOVER;
            this.treeNode13.Name = "treeNode13";
            this.treeNode13.PasswordChar = '\0';
            this.treeNode13.SelectedText = "";
            this.treeNode13.SelectionLength = 0;
            this.treeNode13.SelectionStart = 0;
            this.treeNode13.Size = new System.Drawing.Size(99, 23);
            this.treeNode13.TabIndex = 2;
            this.treeNode13.TabStop = false;
            this.treeNode13.UseSystemPasswordChar = false;
            // 
            // treeNode12
            // 
            this.treeNode12.Depth = 0;
            this.treeNode12.Hint = "子节点2名称";
            this.treeNode12.Location = new System.Drawing.Point(13, 139);
            this.treeNode12.MaxLength = 32767;
            this.treeNode12.MouseState = MaterialSkin.MouseState.HOVER;
            this.treeNode12.Name = "treeNode12";
            this.treeNode12.PasswordChar = '\0';
            this.treeNode12.SelectedText = "";
            this.treeNode12.SelectionLength = 0;
            this.treeNode12.SelectionStart = 0;
            this.treeNode12.Size = new System.Drawing.Size(99, 23);
            this.treeNode12.TabIndex = 1;
            this.treeNode12.TabStop = false;
            this.treeNode12.UseSystemPasswordChar = false;
            // 
            // treeNode1
            // 
            this.treeNode1.Depth = 0;
            this.treeNode1.Hint = "总节点1名称";
            this.treeNode1.Location = new System.Drawing.Point(13, 23);
            this.treeNode1.MaxLength = 32767;
            this.treeNode1.MouseState = MaterialSkin.MouseState.HOVER;
            this.treeNode1.Name = "treeNode1";
            this.treeNode1.PasswordChar = '\0';
            this.treeNode1.SelectedText = "";
            this.treeNode1.SelectionLength = 0;
            this.treeNode1.SelectionStart = 0;
            this.treeNode1.Size = new System.Drawing.Size(99, 23);
            this.treeNode1.TabIndex = 0;
            this.treeNode1.TabStop = false;
            this.treeNode1.UseSystemPasswordChar = false;
            // 
            // treeNode11
            // 
            this.treeNode11.Depth = 0;
            this.treeNode11.Hint = "子节点1名称";
            this.treeNode11.Location = new System.Drawing.Point(13, 81);
            this.treeNode11.MaxLength = 32767;
            this.treeNode11.MouseState = MaterialSkin.MouseState.HOVER;
            this.treeNode11.Name = "treeNode11";
            this.treeNode11.PasswordChar = '\0';
            this.treeNode11.SelectedText = "";
            this.treeNode11.SelectionLength = 0;
            this.treeNode11.SelectionStart = 0;
            this.treeNode11.Size = new System.Drawing.Size(99, 23);
            this.treeNode11.TabIndex = 6;
            this.treeNode11.TabStop = false;
            this.treeNode11.UseSystemPasswordChar = false;
            // 
            // treeNode2
            // 
            this.treeNode2.Depth = 0;
            this.treeNode2.Hint = "总节点2名称";
            this.treeNode2.Location = new System.Drawing.Point(13, 255);
            this.treeNode2.MaxLength = 32767;
            this.treeNode2.MouseState = MaterialSkin.MouseState.HOVER;
            this.treeNode2.Name = "treeNode2";
            this.treeNode2.PasswordChar = '\0';
            this.treeNode2.SelectedText = "";
            this.treeNode2.SelectionLength = 0;
            this.treeNode2.SelectionStart = 0;
            this.treeNode2.Size = new System.Drawing.Size(99, 23);
            this.treeNode2.TabIndex = 7;
            this.treeNode2.TabStop = false;
            this.treeNode2.UseSystemPasswordChar = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::预调试助手.Properties.Resources.配置解释图;
            this.pictureBox2.Location = new System.Drawing.Point(390, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(599, 429);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // tabPage_Gcode
            // 
            this.tabPage_Gcode.Controls.Add(this.Gcodetext);
            this.tabPage_Gcode.Controls.Add(this.btn_Gsave);
            this.tabPage_Gcode.Controls.Add(this.btn_change);
            this.tabPage_Gcode.Location = new System.Drawing.Point(4, 22);
            this.tabPage_Gcode.Name = "tabPage_Gcode";
            this.tabPage_Gcode.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_Gcode.Size = new System.Drawing.Size(989, 476);
            this.tabPage_Gcode.TabIndex = 3;
            this.tabPage_Gcode.Text = "Gcode转换";
            this.tabPage_Gcode.UseVisualStyleBackColor = true;
            // 
            // btn_change
            // 
            this.btn_change.AutoSize = true;
            this.btn_change.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_change.Depth = 0;
            this.btn_change.Icon = null;
            this.btn_change.Location = new System.Drawing.Point(712, 432);
            this.btn_change.MouseState = MaterialSkin.MouseState.HOVER;
            this.btn_change.Name = "btn_change";
            this.btn_change.Primary = true;
            this.btn_change.Size = new System.Drawing.Size(51, 36);
            this.btn_change.TabIndex = 0;
            this.btn_change.Text = "转换";
            this.btn_change.UseVisualStyleBackColor = true;
            this.btn_change.Click += new System.EventHandler(this.btn_change_Click);
            // 
            // btn_Gsave
            // 
            this.btn_Gsave.AutoSize = true;
            this.btn_Gsave.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_Gsave.Depth = 0;
            this.btn_Gsave.Icon = null;
            this.btn_Gsave.Location = new System.Drawing.Point(769, 432);
            this.btn_Gsave.MouseState = MaterialSkin.MouseState.HOVER;
            this.btn_Gsave.Name = "btn_Gsave";
            this.btn_Gsave.Primary = true;
            this.btn_Gsave.Size = new System.Drawing.Size(51, 36);
            this.btn_Gsave.TabIndex = 1;
            this.btn_Gsave.Text = "保存";
            this.btn_Gsave.UseVisualStyleBackColor = true;
            this.btn_Gsave.Click += new System.EventHandler(this.btn_Gsave_Click);
            // 
            // Gcodetext
            // 
            this.Gcodetext.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.Gcodetext.Font = new System.Drawing.Font("阿里巴巴普惠体", 15F);
            this.Gcodetext.Location = new System.Drawing.Point(3, 3);
            this.Gcodetext.Name = "Gcodetext";
            this.Gcodetext.Size = new System.Drawing.Size(703, 470);
            this.Gcodetext.TabIndex = 2;
            this.Gcodetext.Text = "";
            // 
            // btn_downset
            // 
            this.btn_downset.AutoSize = true;
            this.btn_downset.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_downset.Depth = 0;
            this.btn_downset.Icon = null;
            this.btn_downset.Location = new System.Drawing.Point(395, 436);
            this.btn_downset.MouseState = MaterialSkin.MouseState.HOVER;
            this.btn_downset.Name = "btn_downset";
            this.btn_downset.Primary = true;
            this.btn_downset.Size = new System.Drawing.Size(51, 36);
            this.btn_downset.TabIndex = 4;
            this.btn_downset.Text = "下发";
            this.btn_downset.UseVisualStyleBackColor = true;
            this.btn_downset.Click += new System.EventHandler(this.btn_downset_Click);
            // 
            // Form_Guide
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 600);
            this.Controls.Add(this.btn_skip);
            this.Controls.Add(this.materialTabSelector1);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("黑体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form_Guide";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "使用入门";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form_Guide_FormClosed);
            this.Load += new System.EventHandler(this.Form_Guide_Load);
            this.panel1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage_lead.ResumeLayout(false);
            this.panel_pic.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage_setup.ResumeLayout(false);
            this.tabPage_setup.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.tabPage_Gcode.ResumeLayout(false);
            this.tabPage_Gcode.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private HZH_Controls.Controls.GraphicalOverlayComponent graphicalOverlayComponent1;
        private MaterialSkin.Controls.MaterialFlatButton btn_skip;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ToolTip toolTip1;
        private MaterialSkin.Controls.MaterialTabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage_setup;
        private MaterialSkin.Controls.MaterialTabSelector materialTabSelector1;
        private System.Windows.Forms.TabPage tabPage_lead;
        private HZH_Controls.Controls.TreeViewEx treeViewEx1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel_pic;
        private System.Windows.Forms.PictureBox pictureBox1;
        private MaterialSkin.Controls.MaterialSingleLineTextField picPoint21;
        private MaterialSkin.Controls.MaterialSingleLineTextField picPoint23;
        private MaterialSkin.Controls.MaterialSingleLineTextField picPoint22;
        private MaterialSkin.Controls.MaterialSingleLineTextField picPoint13;
        private MaterialSkin.Controls.MaterialSingleLineTextField picPoint12;
        private MaterialSkin.Controls.MaterialSingleLineTextField picPoint11;
        private System.Windows.Forms.GroupBox groupBox2;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtPoint21;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtPoint23;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtPoint22;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtPoint13;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtPoint12;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtPoint11;
        private System.Windows.Forms.GroupBox groupBox3;
        private MaterialSkin.Controls.MaterialSingleLineTextField treeNode2;
        private MaterialSkin.Controls.MaterialSingleLineTextField treeNode11;
        private MaterialSkin.Controls.MaterialSingleLineTextField treeNode21;
        private MaterialSkin.Controls.MaterialSingleLineTextField treeNode23;
        private MaterialSkin.Controls.MaterialSingleLineTextField treeNode22;
        private MaterialSkin.Controls.MaterialSingleLineTextField treeNode13;
        private MaterialSkin.Controls.MaterialSingleLineTextField treeNode12;
        private MaterialSkin.Controls.MaterialSingleLineTextField treeNode1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TabPage tabPage_Gcode;
        private MaterialSkin.Controls.MaterialRaisedButton btn_Gsave;
        private MaterialSkin.Controls.MaterialRaisedButton btn_change;
        private System.Windows.Forms.RichTextBox Gcodetext;
        private MaterialSkin.Controls.MaterialRaisedButton btn_downset;
    }
}
﻿using MaterialSkin;
using MaterialSkin.Controls;
using System;
using System.IO;
using System.Drawing;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace 预调试助手
{
    public partial class Form_Guide : MaterialForm
    {

        string[] stepstr3 = { "欢迎", "使用", "ACS预调试助手" };
        private readonly MaterialSkinManager materialSkinManager;

        string defaultPath;
        string iniPath;

        string AXIS1="", AXIS2="";

        bool firstPoint = false;

        INI iniFile;

        public Form_Guide()
        {
            InitializeComponent();
            materialSkinManager = MaterialSkinManager.Instance;
            materialSkinManager.AddFormToManage(this);
            materialSkinManager.Theme = MaterialSkinManager.Themes.LIGHT;
            materialSkinManager.ColorScheme = new ColorScheme(Primary.BlueGrey800, Primary.BlueGrey900, Primary.BlueGrey500, Accent.LightBlue200, TextShade.WHITE);
        }
        private void Form_Guide_Load(object sender, EventArgs e)
        {

            string str = System.Windows.Forms.Application.StartupPath;
            iniPath = str + "\\config.ini";
            iniFile = new INI(iniPath);
            defaultPath = str + "\\project file";
            NodesChange();
            firstPoint = true;
        }
        private void NodesChange()
        {
            string fanode1 = iniFile.IniReadValue("TreeNodeMean", "FaNode1");
            string subnode11 = iniFile.IniReadValue("TreeNodeMean", "subNode11");
            string subnode12 = iniFile.IniReadValue("TreeNodeMean", "subNode12");
            string subnode13 = iniFile.IniReadValue("TreeNodeMean", "subNode13");
            string fanode2 = iniFile.IniReadValue("TreeNodeMean", "FaNode2");
            string subnode21 = iniFile.IniReadValue("TreeNodeMean", "subNode21");
            string subnode22 = iniFile.IniReadValue("TreeNodeMean", "subNode22");
            string subnode23 = iniFile.IniReadValue("TreeNodeMean", "subNode23");

            AXIS1 = iniFile.IniReadValue("GcodeInfo", "AXIS1");
            AXIS2 = iniFile.IniReadValue("GcodeInfo", "AXIS2");

            treeViewEx1.Nodes.Add(fanode1);
            treeViewEx1.Nodes[0].Nodes.Add(subnode11);
            treeViewEx1.Nodes[0].Nodes.Add(subnode12);
            treeViewEx1.Nodes[0].Nodes.Add(subnode13);
            treeViewEx1.Nodes.Add(fanode2);
            treeViewEx1.Nodes[1].Nodes.Add(subnode21);
            treeViewEx1.Nodes[1].Nodes.Add(subnode22);
            treeViewEx1.Nodes[1].Nodes.Add(subnode23);

            treeViewEx1.ExpandAll();
        }
        private void Pic_creat(string path)
        {
            pictureBox1.Image = Image.FromFile(path);
            //pictureBox2.Image = null;
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
        }
        private void Pic2_creat(string path)
        {
            //pictureBox2.Image = Image.FromFile(path);
            //pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
        }
        private void Txt_creat(string path)
        {
            //richTextBox1.Text = "";
            //try
            //{
            //    // 创建一个 StreamReader 的实例来读取文件 
            //    // using 语句也能关闭 StreamReader
            //    using (StreamReader sr = new StreamReader(path))
            //    {
            //        string line;

            //        // 从文件读取并显示行，直到文件的末尾 
            //        while ((line = sr.ReadLine()) != null)
            //        {
            //            richTextBox1.Text += line + "\n";
            //        }
            //    }
            //}
            //catch (Exception e)
            //{
            //    MessageBox.Show(e.Message + "文件被删除");
            //}
        }
        private void toolTips_show(string path1, string path2)
        {
            //toolTip1.SetToolTip(pictureBox1, "可以更改根目录文件夹下"+ path1 + "文件，格式为JPG");
            //toolTip1.SetToolTip(richTextBox1, "可以更改根目录文件夹下"+path2+"文件，格式为TXT");
        }
        private void treeViewEx1_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left)  //单击鼠标左键才响应
            {
                if (e.Node.Level == 1)                               //判断子节点才响应
                {
                    switch (e.Node.Text)
                    {
                        case "EC连接端口说明":
                            Pic_creat(defaultPath + "\\EC正面图.png");
                            //Txt_creat(defaultPath + "\\EC说明文档.txt");
                            toolTips_show("EC正面图", "EC说明文档");
                            break;
                        case "驱动器连接端口说明":
                            //Pic_creat(defaultPath + "\\驱动器接口图.png");
                            //Txt_creat(defaultPath + "\\驱动器说明文档.txt");
                            toolTips_show("驱动器接口图", "驱动器说明文档");
                            break;
                        case "网线连接示意图":
                            //Pic_creat(defaultPath + "\\网线连接图.png");
                            //Txt_creat(defaultPath + "\\网线连接说明文档.txt");
                            toolTips_show("网线连接图", "网线连接说明文档");
                            break;
                        case "打开ACS软件":
                            //Pic_creat(defaultPath + "\\MMI.png");
                            //Txt_creat(defaultPath + "\\MMI软件说明文档.txt");
                            toolTips_show("MMI", "MMI软件说明文档");
                            break;
                        case "添加控件":
                            //Pic_creat(defaultPath + "\\添加控件.png");
                            //Txt_creat(defaultPath + "\\添加控件说明文档.txt");
                            toolTips_show("添加控件", "添加控件说明文档");
                            break;
                        case "执行System setup":
                            Pic_creat(defaultPath + "\\组网.png");
                            //Pic2_creat(defaultPath + "\\组网后参数.png");
                            //Txt_creat(defaultPath + "\\组网说明文档.txt");
                            toolTips_show("组网", "组网说明文档");
                            break;
                        default:
                            break;
                    }
                    //文件框中显示鼠标点击的节点名称
                }
            }
        }
        private void Form_Guide_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
        private void btn_skip_Click_1(object sender, EventArgs e)
        {
            winMain fm = new winMain();
            fm.Show();
            this.Hide();
        }
        #region G_CODE
        private void btn_change_Click(object sender, EventArgs e)
        {
            Gcodetext.Text = "";
            string path = "";

            OpenFileDialog openFile = new OpenFileDialog();
            openFile.Filter = "txt|*.txt";
            if (openFile.ShowDialog() == DialogResult.OK)
            {
                path = openFile.FileName;
            }
            // 创建一个 StreamReader 的实例来读取文件 
            // using 语句也能关闭 StreamReader
            using (StreamReader sr = new StreamReader(path))
            {
                string line, x_positon = "", y_position = "", vel = "";

                // 从文件读取并显示行，直到文件的末尾 
                while ((line = sr.ReadLine()) != null)
                {
                    if (line.Contains("G01"))
                    {
                        string[] linearray = line.Split(' ');

                        linearray[2] = Regex.Replace(linearray[2], @"[^\d.\d]", "");
                        // 如果是数字，则转换为decimal类型
                        if (Regex.IsMatch(linearray[2], @"^[+-]?\d*[.]?\d*$"))
                        {
                            decimal result = decimal.Parse(linearray[2]);
                            x_positon = result.ToString();
                        }
                        linearray[3] = Regex.Replace(linearray[3], @"[^\d.\d]", "");
                        // 如果是数字，则转换为decimal类型
                        if (Regex.IsMatch(linearray[3], @"^[+-]?\d*[.]?\d*$"))
                        {
                            decimal result = decimal.Parse(linearray[3]);
                            y_position = result.ToString();
                        }
                        linearray[5] = Regex.Replace(linearray[5], @"[^\d.\d]", "");
                        // 如果是数字，则转换为decimal类型
                        if (Regex.IsMatch(linearray[5], @"^[+-]?\d*[.]?\d*$"))
                        {
                            decimal result = decimal.Parse(linearray[5]);
                            double Vel = (double)result / 60;
                            vel = Vel.ToString();
                        }
                    }
                    if (!string.IsNullOrEmpty(x_positon))
                    {
                        if (firstPoint)
                        {
                            Gcodetext.Text += "PTP/E ("+AXIS1+","+AXIS2+")" + x_positon + "," + y_position + "\n";
                            Gcodetext.Text += "XSEG("+AXIS1+","+AXIS2+")" + x_positon + "," + y_position + "\n";
                            firstPoint = false;
                        }
                        else
                        {
                            Gcodetext.Text += "LINE/V ("+AXIS1+","+AXIS2+")," + x_positon + "," + y_position + "," + vel + "\n";
                        }
                    }
                }
                Gcodetext.Text += "ENDS("+AXIS1+","+AXIS2+")" + "\n";
                Gcodetext.Text += "TILL GSEG("+AXIS1+")=-1" + "\n";
                Gcodetext.Text += "STOP" + "\n";
            }
        }

        private void btn_downset_Click(object sender, EventArgs e)
        {
            iniFile.IniWriteValue("TreeNodeMean", "picPoint11",picPoint11.Text);
            iniFile.IniWriteValue("TreeNodeMean", "picPoint12",picPoint12.Text);
            iniFile.IniWriteValue("TreeNodeMean", "picPoint13",picPoint13.Text);
            iniFile.IniWriteValue("TreeNodeMean", "picPoint21",picPoint21.Text);
            iniFile.IniWriteValue("TreeNodeMean", "picPoint22",picPoint22.Text);
            iniFile.IniWriteValue("TreeNodeMean", "picPoint23",picPoint23.Text);

            iniFile.IniWriteValue("TreeNodeMean", "txtPoint1", picPoint11.Text);

        }

        private void btn_Gsave_Click(object sender, EventArgs e)
        {
            firstPoint = true;
            SaveFileDialog saveFile = new SaveFileDialog();
            saveFile.Filter = "txt|*.txt";
            saveFile.FileName = "XSEG.txt";
            if (saveFile.ShowDialog() == DialogResult.OK)
            {
                string Path = saveFile.FileName;
                File.WriteAllText(Path, Gcodetext.Text);
                MessageBox.Show("转换完成");
            }
        }
        #endregion
    }
}
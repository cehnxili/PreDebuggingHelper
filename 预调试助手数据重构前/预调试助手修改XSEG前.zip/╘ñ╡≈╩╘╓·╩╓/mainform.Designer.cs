﻿namespace 预调试助手
{
    partial class winMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(winMain));
            this.tbox_VEL = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.gbox_fault = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.gbox_motionprofile = new System.Windows.Forms.GroupBox();
            this.tbox_JERK = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.tbox_KDEC = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.tbox_DEC = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.tbox_ACC = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.time_Update = new System.Windows.Forms.Timer(this.components);
            this.gbox_positon = new System.Windows.Forms.GroupBox();
            this.tbox_PE = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.tbox_FVEL = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.tbox_FPOS = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.tbox_RPOS = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.btn_set0 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_abposition = new MaterialSkin.Controls.MaterialRaisedButton();
            this.btn_positive = new MaterialSkin.Controls.MaterialRaisedButton();
            this.btn_NEposition = new MaterialSkin.Controls.MaterialRaisedButton();
            this.tbox_position_dis = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.tbox_JOGspeed = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.btn_JOGRE = new MaterialSkin.Controls.MaterialRaisedButton();
            this.btn_JOGNE = new MaterialSkin.Controls.MaterialRaisedButton();
            this.cbox_useJOG = new System.Windows.Forms.CheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tbox_IP = new System.Windows.Forms.TextBox();
            this.rbox_terminal = new System.Windows.Forms.RichTextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tbox_Terminal = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.btn_save = new MaterialSkin.Controls.MaterialRaisedButton();
            this.btn_clear = new MaterialSkin.Controls.MaterialRaisedButton();
            this.btn_send = new MaterialSkin.Controls.MaterialRaisedButton();
            this.saveFile = new System.Windows.Forms.SaveFileDialog();
            this.cbBox_enable = new System.Windows.Forms.ComboBox();
            this.materialLabel1 = new MaterialSkin.Controls.MaterialLabel();
            this.btn_enable = new MaterialSkin.Controls.MaterialRaisedButton();
            this.btn_disable = new MaterialSkin.Controls.MaterialRaisedButton();
            this.btn_connect = new MaterialSkin.Controls.MaterialFlatButton();
            this.ucBtnExt1 = new MaterialSkin.Controls.MaterialFlatButton();
            this.rbtn_TcpIp = new MaterialSkin.Controls.MaterialRadioButton();
            this.rbtn_sim = new MaterialSkin.Controls.MaterialRadioButton();
            this.Enable_baidu = new MaterialSkin.Controls.MaterialCheckBox();
            this.btn_STOP = new MaterialSkin.Controls.MaterialRaisedButton();
            this.btn_clearFault = new MaterialSkin.Controls.MaterialRaisedButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tbox_delayTime = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.btn_readB = new System.Windows.Forms.Label();
            this.btn_readA = new System.Windows.Forms.Label();
            this.tbox_BPosition = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.btn_statABMotion = new MaterialSkin.Controls.MaterialRaisedButton();
            this.tbox_APosition = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.LED_enable = new System.Windows.Forms.Label();
            this.LED_inposition = new System.Windows.Forms.Label();
            this.LED_ACCing = new System.Windows.Forms.Label();
            this.LED_moveing = new System.Windows.Forms.Label();
            this.gbox_fault.SuspendLayout();
            this.gbox_motionprofile.SuspendLayout();
            this.gbox_positon.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbox_VEL
            // 
            this.tbox_VEL.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tbox_VEL.Depth = 0;
            this.tbox_VEL.Hint = "   VEL";
            this.tbox_VEL.Location = new System.Drawing.Point(105, 24);
            this.tbox_VEL.MaxLength = 32767;
            this.tbox_VEL.MouseState = MaterialSkin.MouseState.HOVER;
            this.tbox_VEL.Name = "tbox_VEL";
            this.tbox_VEL.PasswordChar = '\0';
            this.tbox_VEL.SelectedText = "";
            this.tbox_VEL.SelectionLength = 0;
            this.tbox_VEL.SelectionStart = 0;
            this.tbox_VEL.Size = new System.Drawing.Size(100, 23);
            this.tbox_VEL.TabIndex = 0;
            this.tbox_VEL.TabStop = false;
            this.tbox_VEL.UseSystemPasswordChar = false;
            this.tbox_VEL.Enter += new System.EventHandler(this.TextBoxes_Enter);
            this.tbox_VEL.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxes_KeyPress);
            this.tbox_VEL.Leave += new System.EventHandler(this.TextBoxes_Leave);
            // 
            // gbox_fault
            // 
            this.gbox_fault.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbox_fault.AutoSize = true;
            this.gbox_fault.Controls.Add(this.label4);
            this.gbox_fault.Controls.Add(this.label3);
            this.gbox_fault.Controls.Add(this.label2);
            this.gbox_fault.Font = new System.Drawing.Font("宋体", 9F);
            this.gbox_fault.Location = new System.Drawing.Point(1, 115);
            this.gbox_fault.Name = "gbox_fault";
            this.gbox_fault.Size = new System.Drawing.Size(1281, 107);
            this.gbox_fault.TabIndex = 5;
            this.gbox_fault.TabStop = false;
            this.gbox_fault.Text = "限位";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(5, 78);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 7;
            this.label4.Text = "右限位：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(5, 51);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 6;
            this.label3.Text = "左限位：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(5, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 6;
            this.label2.Text = "轴号：";
            // 
            // gbox_motionprofile
            // 
            this.gbox_motionprofile.Controls.Add(this.tbox_JERK);
            this.gbox_motionprofile.Controls.Add(this.tbox_KDEC);
            this.gbox_motionprofile.Controls.Add(this.tbox_DEC);
            this.gbox_motionprofile.Controls.Add(this.tbox_ACC);
            this.gbox_motionprofile.Controls.Add(this.tbox_VEL);
            this.gbox_motionprofile.Controls.Add(this.label17);
            this.gbox_motionprofile.Controls.Add(this.label16);
            this.gbox_motionprofile.Controls.Add(this.label15);
            this.gbox_motionprofile.Controls.Add(this.label14);
            this.gbox_motionprofile.Controls.Add(this.label13);
            this.gbox_motionprofile.Location = new System.Drawing.Point(1, 225);
            this.gbox_motionprofile.Name = "gbox_motionprofile";
            this.gbox_motionprofile.Size = new System.Drawing.Size(212, 163);
            this.gbox_motionprofile.TabIndex = 6;
            this.gbox_motionprofile.TabStop = false;
            this.gbox_motionprofile.Text = "运动参数";
            // 
            // tbox_JERK
            // 
            this.tbox_JERK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tbox_JERK.Depth = 0;
            this.tbox_JERK.Hint = "   JERK";
            this.tbox_JERK.Location = new System.Drawing.Point(105, 137);
            this.tbox_JERK.MaxLength = 32767;
            this.tbox_JERK.MouseState = MaterialSkin.MouseState.HOVER;
            this.tbox_JERK.Name = "tbox_JERK";
            this.tbox_JERK.PasswordChar = '\0';
            this.tbox_JERK.SelectedText = "";
            this.tbox_JERK.SelectionLength = 0;
            this.tbox_JERK.SelectionStart = 0;
            this.tbox_JERK.Size = new System.Drawing.Size(100, 23);
            this.tbox_JERK.TabIndex = 4;
            this.tbox_JERK.TabStop = false;
            this.tbox_JERK.UseSystemPasswordChar = false;
            this.tbox_JERK.Enter += new System.EventHandler(this.TextBoxes_Enter);
            this.tbox_JERK.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxes_KeyPress);
            this.tbox_JERK.Leave += new System.EventHandler(this.TextBoxes_Leave);
            // 
            // tbox_KDEC
            // 
            this.tbox_KDEC.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tbox_KDEC.Depth = 0;
            this.tbox_KDEC.Hint = "   KDEC";
            this.tbox_KDEC.Location = new System.Drawing.Point(105, 105);
            this.tbox_KDEC.MaxLength = 32767;
            this.tbox_KDEC.MouseState = MaterialSkin.MouseState.HOVER;
            this.tbox_KDEC.Name = "tbox_KDEC";
            this.tbox_KDEC.PasswordChar = '\0';
            this.tbox_KDEC.SelectedText = "";
            this.tbox_KDEC.SelectionLength = 0;
            this.tbox_KDEC.SelectionStart = 0;
            this.tbox_KDEC.Size = new System.Drawing.Size(100, 23);
            this.tbox_KDEC.TabIndex = 3;
            this.tbox_KDEC.TabStop = false;
            this.tbox_KDEC.UseSystemPasswordChar = false;
            this.tbox_KDEC.Enter += new System.EventHandler(this.TextBoxes_Enter);
            this.tbox_KDEC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxes_KeyPress);
            this.tbox_KDEC.Leave += new System.EventHandler(this.TextBoxes_Leave);
            // 
            // tbox_DEC
            // 
            this.tbox_DEC.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tbox_DEC.Depth = 0;
            this.tbox_DEC.Hint = "   DEC";
            this.tbox_DEC.Location = new System.Drawing.Point(105, 76);
            this.tbox_DEC.MaxLength = 32767;
            this.tbox_DEC.MouseState = MaterialSkin.MouseState.HOVER;
            this.tbox_DEC.Name = "tbox_DEC";
            this.tbox_DEC.PasswordChar = '\0';
            this.tbox_DEC.SelectedText = "";
            this.tbox_DEC.SelectionLength = 0;
            this.tbox_DEC.SelectionStart = 0;
            this.tbox_DEC.Size = new System.Drawing.Size(100, 23);
            this.tbox_DEC.TabIndex = 2;
            this.tbox_DEC.TabStop = false;
            this.tbox_DEC.UseSystemPasswordChar = false;
            this.tbox_DEC.Enter += new System.EventHandler(this.TextBoxes_Enter);
            this.tbox_DEC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxes_KeyPress);
            this.tbox_DEC.Leave += new System.EventHandler(this.TextBoxes_Leave);
            // 
            // tbox_ACC
            // 
            this.tbox_ACC.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tbox_ACC.Depth = 0;
            this.tbox_ACC.Hint = "   ACC";
            this.tbox_ACC.Location = new System.Drawing.Point(105, 49);
            this.tbox_ACC.MaxLength = 32767;
            this.tbox_ACC.MouseState = MaterialSkin.MouseState.HOVER;
            this.tbox_ACC.Name = "tbox_ACC";
            this.tbox_ACC.PasswordChar = '\0';
            this.tbox_ACC.SelectedText = "";
            this.tbox_ACC.SelectionLength = 0;
            this.tbox_ACC.SelectionStart = 0;
            this.tbox_ACC.Size = new System.Drawing.Size(100, 23);
            this.tbox_ACC.TabIndex = 1;
            this.tbox_ACC.TabStop = false;
            this.tbox_ACC.UseSystemPasswordChar = false;
            this.tbox_ACC.Enter += new System.EventHandler(this.TextBoxes_Enter);
            this.tbox_ACC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxes_KeyPress);
            this.tbox_ACC.Leave += new System.EventHandler(this.TextBoxes_Leave);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(6, 142);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(89, 12);
            this.label17.TabIndex = 11;
            this.label17.Text = "加加速度(JERK)";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(6, 113);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(89, 12);
            this.label16.TabIndex = 10;
            this.label16.Text = "刹车速度(KDEC)";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(6, 84);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(71, 12);
            this.label15.TabIndex = 9;
            this.label15.Text = "减速度(DEC)";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 55);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(71, 12);
            this.label14.TabIndex = 8;
            this.label14.Text = "加速度(ACC)";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 26);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(59, 12);
            this.label13.TabIndex = 7;
            this.label13.Text = "速度(VEL)";
            // 
            // time_Update
            // 
            this.time_Update.Interval = 50;
            this.time_Update.Tick += new System.EventHandler(this.time_Update_Tick);
            // 
            // gbox_positon
            // 
            this.gbox_positon.Controls.Add(this.tbox_PE);
            this.gbox_positon.Controls.Add(this.tbox_FVEL);
            this.gbox_positon.Controls.Add(this.tbox_FPOS);
            this.gbox_positon.Controls.Add(this.tbox_RPOS);
            this.gbox_positon.Controls.Add(this.btn_set0);
            this.gbox_positon.Controls.Add(this.label19);
            this.gbox_positon.Controls.Add(this.label20);
            this.gbox_positon.Controls.Add(this.label21);
            this.gbox_positon.Controls.Add(this.label22);
            this.gbox_positon.Location = new System.Drawing.Point(218, 225);
            this.gbox_positon.Name = "gbox_positon";
            this.gbox_positon.Size = new System.Drawing.Size(212, 163);
            this.gbox_positon.TabIndex = 7;
            this.gbox_positon.TabStop = false;
            this.gbox_positon.Text = "当前位置";
            // 
            // tbox_PE
            // 
            this.tbox_PE.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tbox_PE.Depth = 0;
            this.tbox_PE.Hint = "   PE";
            this.tbox_PE.Location = new System.Drawing.Point(105, 105);
            this.tbox_PE.MaxLength = 32767;
            this.tbox_PE.MouseState = MaterialSkin.MouseState.HOVER;
            this.tbox_PE.Name = "tbox_PE";
            this.tbox_PE.PasswordChar = '\0';
            this.tbox_PE.SelectedText = "";
            this.tbox_PE.SelectionLength = 0;
            this.tbox_PE.SelectionStart = 0;
            this.tbox_PE.Size = new System.Drawing.Size(100, 23);
            this.tbox_PE.TabIndex = 46;
            this.tbox_PE.TabStop = false;
            this.tbox_PE.UseSystemPasswordChar = false;
            // 
            // tbox_FVEL
            // 
            this.tbox_FVEL.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tbox_FVEL.Depth = 0;
            this.tbox_FVEL.Hint = "   FEVL";
            this.tbox_FVEL.Location = new System.Drawing.Point(105, 76);
            this.tbox_FVEL.MaxLength = 32767;
            this.tbox_FVEL.MouseState = MaterialSkin.MouseState.HOVER;
            this.tbox_FVEL.Name = "tbox_FVEL";
            this.tbox_FVEL.PasswordChar = '\0';
            this.tbox_FVEL.SelectedText = "";
            this.tbox_FVEL.SelectionLength = 0;
            this.tbox_FVEL.SelectionStart = 0;
            this.tbox_FVEL.Size = new System.Drawing.Size(100, 23);
            this.tbox_FVEL.TabIndex = 45;
            this.tbox_FVEL.TabStop = false;
            this.tbox_FVEL.UseSystemPasswordChar = false;
            // 
            // tbox_FPOS
            // 
            this.tbox_FPOS.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tbox_FPOS.Depth = 0;
            this.tbox_FPOS.Hint = "   FPOS";
            this.tbox_FPOS.Location = new System.Drawing.Point(105, 49);
            this.tbox_FPOS.MaxLength = 32767;
            this.tbox_FPOS.MouseState = MaterialSkin.MouseState.HOVER;
            this.tbox_FPOS.Name = "tbox_FPOS";
            this.tbox_FPOS.PasswordChar = '\0';
            this.tbox_FPOS.SelectedText = "";
            this.tbox_FPOS.SelectionLength = 0;
            this.tbox_FPOS.SelectionStart = 0;
            this.tbox_FPOS.Size = new System.Drawing.Size(100, 23);
            this.tbox_FPOS.TabIndex = 44;
            this.tbox_FPOS.TabStop = false;
            this.tbox_FPOS.UseSystemPasswordChar = false;
            // 
            // tbox_RPOS
            // 
            this.tbox_RPOS.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tbox_RPOS.Depth = 0;
            this.tbox_RPOS.Hint = "   RPOS";
            this.tbox_RPOS.Location = new System.Drawing.Point(105, 20);
            this.tbox_RPOS.MaxLength = 32767;
            this.tbox_RPOS.MouseState = MaterialSkin.MouseState.HOVER;
            this.tbox_RPOS.Name = "tbox_RPOS";
            this.tbox_RPOS.PasswordChar = '\0';
            this.tbox_RPOS.SelectedText = "";
            this.tbox_RPOS.SelectionLength = 0;
            this.tbox_RPOS.SelectionStart = 0;
            this.tbox_RPOS.Size = new System.Drawing.Size(100, 23);
            this.tbox_RPOS.TabIndex = 43;
            this.tbox_RPOS.TabStop = false;
            this.tbox_RPOS.UseSystemPasswordChar = false;
            // 
            // btn_set0
            // 
            this.btn_set0.AutoSize = true;
            this.btn_set0.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_set0.Depth = 0;
            this.btn_set0.Icon = null;
            this.btn_set0.Location = new System.Drawing.Point(8, 130);
            this.btn_set0.MouseState = MaterialSkin.MouseState.HOVER;
            this.btn_set0.Name = "btn_set0";
            this.btn_set0.Primary = true;
            this.btn_set0.Size = new System.Drawing.Size(134, 36);
            this.btn_set0.TabIndex = 37;
            this.btn_set0.Text = "设置当前位置为0";
            this.btn_set0.UseVisualStyleBackColor = true;
            this.btn_set0.Click += new System.EventHandler(this.btn_set0_BtnClick);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(6, 113);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(77, 12);
            this.label19.TabIndex = 10;
            this.label19.Text = "位置误差(PE)";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(6, 84);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(89, 12);
            this.label20.TabIndex = 9;
            this.label20.Text = "反馈速度(FVEL)";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(6, 55);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(89, 12);
            this.label21.TabIndex = 8;
            this.label21.Text = "反馈位置(FPOS)";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(6, 26);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(89, 12);
            this.label22.TabIndex = 7;
            this.label22.Text = "参考位置(RPOS)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(366, 72);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 12);
            this.label5.TabIndex = 8;
            this.label5.Text = "移动中";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(454, 72);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 12);
            this.label6.TabIndex = 9;
            this.label6.Text = "加速中";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(618, 72);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 12);
            this.label7.TabIndex = 10;
            this.label7.Text = "到位";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(542, 72);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 12);
            this.label8.TabIndex = 11;
            this.label8.Text = "使能";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn_abposition);
            this.groupBox1.Controls.Add(this.btn_positive);
            this.groupBox1.Controls.Add(this.btn_NEposition);
            this.groupBox1.Controls.Add(this.tbox_position_dis);
            this.groupBox1.Controls.Add(this.tbox_JOGspeed);
            this.groupBox1.Controls.Add(this.btn_JOGRE);
            this.groupBox1.Controls.Add(this.btn_JOGNE);
            this.groupBox1.Controls.Add(this.cbox_useJOG);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Location = new System.Drawing.Point(435, 225);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 163);
            this.groupBox1.TabIndex = 16;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "运动控制";
            // 
            // btn_abposition
            // 
            this.btn_abposition.AutoSize = true;
            this.btn_abposition.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_abposition.Depth = 0;
            this.btn_abposition.Icon = null;
            this.btn_abposition.Location = new System.Drawing.Point(9, 109);
            this.btn_abposition.MouseState = MaterialSkin.MouseState.HOVER;
            this.btn_abposition.Name = "btn_abposition";
            this.btn_abposition.Primary = true;
            this.btn_abposition.Size = new System.Drawing.Size(127, 36);
            this.btn_abposition.TabIndex = 46;
            this.btn_abposition.Text = "移动到绝对位置";
            this.btn_abposition.UseVisualStyleBackColor = true;
            this.btn_abposition.Click += new System.EventHandler(this.btn_abposition_Click);
            // 
            // btn_positive
            // 
            this.btn_positive.AutoSize = true;
            this.btn_positive.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_positive.Depth = 0;
            this.btn_positive.Icon = null;
            this.btn_positive.Location = new System.Drawing.Point(121, 138);
            this.btn_positive.MouseState = MaterialSkin.MouseState.HOVER;
            this.btn_positive.Name = "btn_positive";
            this.btn_positive.Primary = true;
            this.btn_positive.Size = new System.Drawing.Size(51, 36);
            this.btn_positive.TabIndex = 45;
            this.btn_positive.Text = "正向";
            this.btn_positive.UseVisualStyleBackColor = true;
            this.btn_positive.Click += new System.EventHandler(this.btn_positive_Click);
            // 
            // btn_NEposition
            // 
            this.btn_NEposition.AutoSize = true;
            this.btn_NEposition.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_NEposition.Depth = 0;
            this.btn_NEposition.Icon = null;
            this.btn_NEposition.Location = new System.Drawing.Point(9, 138);
            this.btn_NEposition.MouseState = MaterialSkin.MouseState.HOVER;
            this.btn_NEposition.Name = "btn_NEposition";
            this.btn_NEposition.Primary = true;
            this.btn_NEposition.Size = new System.Drawing.Size(51, 36);
            this.btn_NEposition.TabIndex = 44;
            this.btn_NEposition.Text = "负向";
            this.btn_NEposition.UseVisualStyleBackColor = true;
            this.btn_NEposition.Click += new System.EventHandler(this.btn_NEposition_Click);
            // 
            // tbox_position_dis
            // 
            this.tbox_position_dis.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tbox_position_dis.Depth = 0;
            this.tbox_position_dis.Hint = "  位置\\间隔";
            this.tbox_position_dis.Location = new System.Drawing.Point(107, 89);
            this.tbox_position_dis.MaxLength = 32767;
            this.tbox_position_dis.MouseState = MaterialSkin.MouseState.HOVER;
            this.tbox_position_dis.Name = "tbox_position_dis";
            this.tbox_position_dis.PasswordChar = '\0';
            this.tbox_position_dis.SelectedText = "";
            this.tbox_position_dis.SelectionLength = 0;
            this.tbox_position_dis.SelectionStart = 0;
            this.tbox_position_dis.Size = new System.Drawing.Size(87, 23);
            this.tbox_position_dis.TabIndex = 43;
            this.tbox_position_dis.TabStop = false;
            this.tbox_position_dis.UseSystemPasswordChar = false;
            // 
            // tbox_JOGspeed
            // 
            this.tbox_JOGspeed.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tbox_JOGspeed.Depth = 0;
            this.tbox_JOGspeed.Hint = "   JOG速度";
            this.tbox_JOGspeed.Location = new System.Drawing.Point(107, 20);
            this.tbox_JOGspeed.MaxLength = 32767;
            this.tbox_JOGspeed.MouseState = MaterialSkin.MouseState.HOVER;
            this.tbox_JOGspeed.Name = "tbox_JOGspeed";
            this.tbox_JOGspeed.PasswordChar = '\0';
            this.tbox_JOGspeed.SelectedText = "";
            this.tbox_JOGspeed.SelectionLength = 0;
            this.tbox_JOGspeed.SelectionStart = 0;
            this.tbox_JOGspeed.Size = new System.Drawing.Size(87, 23);
            this.tbox_JOGspeed.TabIndex = 42;
            this.tbox_JOGspeed.TabStop = false;
            this.tbox_JOGspeed.UseSystemPasswordChar = false;
            // 
            // btn_JOGRE
            // 
            this.btn_JOGRE.AutoSize = true;
            this.btn_JOGRE.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_JOGRE.Depth = 0;
            this.btn_JOGRE.Icon = null;
            this.btn_JOGRE.Location = new System.Drawing.Point(121, 43);
            this.btn_JOGRE.MouseState = MaterialSkin.MouseState.HOVER;
            this.btn_JOGRE.Name = "btn_JOGRE";
            this.btn_JOGRE.Primary = true;
            this.btn_JOGRE.Size = new System.Drawing.Size(51, 36);
            this.btn_JOGRE.TabIndex = 38;
            this.btn_JOGRE.Text = "正向";
            this.btn_JOGRE.UseVisualStyleBackColor = true;
            this.btn_JOGRE.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btn_JOGRE_MouseDown);
            this.btn_JOGRE.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btn_JOGRE_MouseUp);
            // 
            // btn_JOGNE
            // 
            this.btn_JOGNE.AutoSize = true;
            this.btn_JOGNE.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_JOGNE.Depth = 0;
            this.btn_JOGNE.Icon = null;
            this.btn_JOGNE.Location = new System.Drawing.Point(9, 45);
            this.btn_JOGNE.MouseState = MaterialSkin.MouseState.HOVER;
            this.btn_JOGNE.Name = "btn_JOGNE";
            this.btn_JOGNE.Primary = true;
            this.btn_JOGNE.Size = new System.Drawing.Size(51, 36);
            this.btn_JOGNE.TabIndex = 37;
            this.btn_JOGNE.Text = "负向";
            this.btn_JOGNE.UseVisualStyleBackColor = true;
            this.btn_JOGNE.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btn_JOGNE_MouseDown);
            this.btn_JOGNE.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btn_JOGNE_MouseUp);
            // 
            // cbox_useJOG
            // 
            this.cbox_useJOG.AutoSize = true;
            this.cbox_useJOG.Location = new System.Drawing.Point(91, 26);
            this.cbox_useJOG.Name = "cbox_useJOG";
            this.cbox_useJOG.Size = new System.Drawing.Size(15, 14);
            this.cbox_useJOG.TabIndex = 23;
            this.cbox_useJOG.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label11.Location = new System.Drawing.Point(2, 74);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(197, 12);
            this.label11.TabIndex = 17;
            this.label11.Text = "--------------------------------";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(7, 94);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 12);
            this.label10.TabIndex = 17;
            this.label10.Text = "位置、间距";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(7, 26);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(83, 12);
            this.label9.TabIndex = 17;
            this.label9.Text = "点动(JOG)速度";
            // 
            // tbox_IP
            // 
            this.tbox_IP.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.tbox_IP.Location = new System.Drawing.Point(73, 557);
            this.tbox_IP.Name = "tbox_IP";
            this.tbox_IP.Size = new System.Drawing.Size(116, 21);
            this.tbox_IP.TabIndex = 19;
            // 
            // rbox_terminal
            // 
            this.rbox_terminal.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rbox_terminal.Font = new System.Drawing.Font("宋体", 15F);
            this.rbox_terminal.Location = new System.Drawing.Point(1, 438);
            this.rbox_terminal.Name = "rbox_terminal";
            this.rbox_terminal.ReadOnly = true;
            this.rbox_terminal.Size = new System.Drawing.Size(1281, 116);
            this.rbox_terminal.TabIndex = 23;
            this.rbox_terminal.Text = "";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.tbox_Terminal);
            this.groupBox2.Controls.Add(this.btn_save);
            this.groupBox2.Controls.Add(this.btn_clear);
            this.groupBox2.Controls.Add(this.btn_send);
            this.groupBox2.Location = new System.Drawing.Point(1, 400);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1281, 33);
            this.groupBox2.TabIndex = 25;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "通讯终端";
            // 
            // tbox_Terminal
            // 
            this.tbox_Terminal.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tbox_Terminal.Depth = 0;
            this.tbox_Terminal.Hint = "通讯终端输入框";
            this.tbox_Terminal.Location = new System.Drawing.Point(63, 10);
            this.tbox_Terminal.MaxLength = 32767;
            this.tbox_Terminal.MouseState = MaterialSkin.MouseState.HOVER;
            this.tbox_Terminal.Name = "tbox_Terminal";
            this.tbox_Terminal.PasswordChar = '\0';
            this.tbox_Terminal.SelectedText = "";
            this.tbox_Terminal.SelectionLength = 0;
            this.tbox_Terminal.SelectionStart = 0;
            this.tbox_Terminal.Size = new System.Drawing.Size(973, 23);
            this.tbox_Terminal.TabIndex = 41;
            this.tbox_Terminal.TabStop = false;
            this.tbox_Terminal.UseSystemPasswordChar = false;
            this.tbox_Terminal.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbox_Terminal_KeyDown);
            // 
            // btn_save
            // 
            this.btn_save.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btn_save.AutoSize = true;
            this.btn_save.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_save.Depth = 0;
            this.btn_save.Icon = null;
            this.btn_save.Location = new System.Drawing.Point(1121, 9);
            this.btn_save.MouseState = MaterialSkin.MouseState.HOVER;
            this.btn_save.Name = "btn_save";
            this.btn_save.Primary = true;
            this.btn_save.Size = new System.Drawing.Size(51, 36);
            this.btn_save.TabIndex = 40;
            this.btn_save.Text = "保存";
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new System.EventHandler(this.btn_save_BtnClick);
            // 
            // btn_clear
            // 
            this.btn_clear.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_clear.AutoSize = true;
            this.btn_clear.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_clear.Depth = 0;
            this.btn_clear.Icon = null;
            this.btn_clear.Location = new System.Drawing.Point(1200, 9);
            this.btn_clear.MouseState = MaterialSkin.MouseState.HOVER;
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Primary = true;
            this.btn_clear.Size = new System.Drawing.Size(51, 36);
            this.btn_clear.TabIndex = 39;
            this.btn_clear.Text = "清空";
            this.btn_clear.UseVisualStyleBackColor = true;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_BtnClick);
            // 
            // btn_send
            // 
            this.btn_send.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btn_send.AutoSize = true;
            this.btn_send.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_send.Depth = 0;
            this.btn_send.Icon = null;
            this.btn_send.Location = new System.Drawing.Point(1042, 9);
            this.btn_send.MouseState = MaterialSkin.MouseState.HOVER;
            this.btn_send.Name = "btn_send";
            this.btn_send.Primary = true;
            this.btn_send.Size = new System.Drawing.Size(51, 36);
            this.btn_send.TabIndex = 38;
            this.btn_send.Text = "发送";
            this.btn_send.UseVisualStyleBackColor = true;
            this.btn_send.Click += new System.EventHandler(this.btn_send_BtnClick);
            // 
            // cbBox_enable
            // 
            this.cbBox_enable.FormattingEnabled = true;
            this.cbBox_enable.Location = new System.Drawing.Point(71, 75);
            this.cbBox_enable.Name = "cbBox_enable";
            this.cbBox_enable.Size = new System.Drawing.Size(121, 20);
            this.cbBox_enable.TabIndex = 30;
            this.cbBox_enable.SelectedIndexChanged += new System.EventHandler(this.cbBox_enable_SelectedIndexChanged_1);
            // 
            // materialLabel1
            // 
            this.materialLabel1.AutoSize = true;
            this.materialLabel1.Depth = 0;
            this.materialLabel1.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel1.Location = new System.Drawing.Point(1, 76);
            this.materialLabel1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel1.Name = "materialLabel1";
            this.materialLabel1.Size = new System.Drawing.Size(73, 19);
            this.materialLabel1.TabIndex = 34;
            this.materialLabel1.Text = "轴选择：";
            // 
            // btn_enable
            // 
            this.btn_enable.AutoSize = true;
            this.btn_enable.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_enable.Depth = 0;
            this.btn_enable.Icon = null;
            this.btn_enable.Location = new System.Drawing.Point(198, 69);
            this.btn_enable.MouseState = MaterialSkin.MouseState.HOVER;
            this.btn_enable.Name = "btn_enable";
            this.btn_enable.Primary = true;
            this.btn_enable.Size = new System.Drawing.Size(66, 36);
            this.btn_enable.TabIndex = 35;
            this.btn_enable.Text = "上使能";
            this.btn_enable.UseVisualStyleBackColor = true;
            this.btn_enable.Click += new System.EventHandler(this.btn_enable_BtnClick);
            // 
            // btn_disable
            // 
            this.btn_disable.AutoSize = true;
            this.btn_disable.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_disable.Depth = 0;
            this.btn_disable.Icon = null;
            this.btn_disable.Location = new System.Drawing.Point(270, 69);
            this.btn_disable.MouseState = MaterialSkin.MouseState.HOVER;
            this.btn_disable.Name = "btn_disable";
            this.btn_disable.Primary = true;
            this.btn_disable.Size = new System.Drawing.Size(66, 36);
            this.btn_disable.TabIndex = 36;
            this.btn_disable.Text = "断使能";
            this.btn_disable.UseVisualStyleBackColor = true;
            this.btn_disable.Click += new System.EventHandler(this.btn_disable_BtnClick);
            // 
            // btn_connect
            // 
            this.btn_connect.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_connect.AutoSize = true;
            this.btn_connect.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_connect.Depth = 0;
            this.btn_connect.Icon = null;
            this.btn_connect.Location = new System.Drawing.Point(1148, 560);
            this.btn_connect.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.btn_connect.MouseState = MaterialSkin.MouseState.HOVER;
            this.btn_connect.Name = "btn_connect";
            this.btn_connect.Primary = false;
            this.btn_connect.Size = new System.Drawing.Size(75, 36);
            this.btn_connect.TabIndex = 2;
            this.btn_connect.Text = "连       接";
            this.btn_connect.UseVisualStyleBackColor = true;
            this.btn_connect.Click += new System.EventHandler(this.btn_connect_BtnClick);
            // 
            // ucBtnExt1
            // 
            this.ucBtnExt1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ucBtnExt1.AutoSize = true;
            this.ucBtnExt1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ucBtnExt1.Depth = 0;
            this.ucBtnExt1.Icon = null;
            this.ucBtnExt1.Location = new System.Drawing.Point(1231, 560);
            this.ucBtnExt1.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.ucBtnExt1.MouseState = MaterialSkin.MouseState.HOVER;
            this.ucBtnExt1.Name = "ucBtnExt1";
            this.ucBtnExt1.Primary = false;
            this.ucBtnExt1.Size = new System.Drawing.Size(51, 36);
            this.ucBtnExt1.TabIndex = 37;
            this.ucBtnExt1.Text = "返回";
            this.ucBtnExt1.UseVisualStyleBackColor = true;
            this.ucBtnExt1.Click += new System.EventHandler(this.ucBtnExt1_BtnClick);
            // 
            // rbtn_TcpIp
            // 
            this.rbtn_TcpIp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.rbtn_TcpIp.Depth = 0;
            this.rbtn_TcpIp.Font = new System.Drawing.Font("Roboto", 10F);
            this.rbtn_TcpIp.Location = new System.Drawing.Point(1, 557);
            this.rbtn_TcpIp.Margin = new System.Windows.Forms.Padding(0);
            this.rbtn_TcpIp.MouseLocation = new System.Drawing.Point(-1, -1);
            this.rbtn_TcpIp.MouseState = MaterialSkin.MouseState.HOVER;
            this.rbtn_TcpIp.Name = "rbtn_TcpIp";
            this.rbtn_TcpIp.Ripple = true;
            this.rbtn_TcpIp.Size = new System.Drawing.Size(69, 20);
            this.rbtn_TcpIp.TabIndex = 38;
            this.rbtn_TcpIp.TabStop = true;
            this.rbtn_TcpIp.Text = "TCP/IP";
            this.rbtn_TcpIp.UseVisualStyleBackColor = true;
            // 
            // rbtn_sim
            // 
            this.rbtn_sim.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.rbtn_sim.Depth = 0;
            this.rbtn_sim.Font = new System.Drawing.Font("Roboto", 10F);
            this.rbtn_sim.Location = new System.Drawing.Point(1, 580);
            this.rbtn_sim.Margin = new System.Windows.Forms.Padding(0);
            this.rbtn_sim.MouseLocation = new System.Drawing.Point(-1, -1);
            this.rbtn_sim.MouseState = MaterialSkin.MouseState.HOVER;
            this.rbtn_sim.Name = "rbtn_sim";
            this.rbtn_sim.Ripple = true;
            this.rbtn_sim.Size = new System.Drawing.Size(69, 20);
            this.rbtn_sim.TabIndex = 39;
            this.rbtn_sim.TabStop = true;
            this.rbtn_sim.Text = "仿真";
            this.rbtn_sim.UseVisualStyleBackColor = true;
            // 
            // Enable_baidu
            // 
            this.Enable_baidu.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.Enable_baidu.Depth = 0;
            this.Enable_baidu.Font = new System.Drawing.Font("Roboto", 10F);
            this.Enable_baidu.Location = new System.Drawing.Point(72, 580);
            this.Enable_baidu.Margin = new System.Windows.Forms.Padding(0);
            this.Enable_baidu.MouseLocation = new System.Drawing.Point(-1, -1);
            this.Enable_baidu.MouseState = MaterialSkin.MouseState.HOVER;
            this.Enable_baidu.Name = "Enable_baidu";
            this.Enable_baidu.Ripple = true;
            this.Enable_baidu.Size = new System.Drawing.Size(120, 20);
            this.Enable_baidu.TabIndex = 40;
            this.Enable_baidu.Text = "启用百度翻译";
            this.Enable_baidu.UseVisualStyleBackColor = true;
            // 
            // btn_STOP
            // 
            this.btn_STOP.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_STOP.AutoSize = true;
            this.btn_STOP.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_STOP.Depth = 0;
            this.btn_STOP.Font = new System.Drawing.Font("宋体", 42F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_STOP.Icon = null;
            this.btn_STOP.Location = new System.Drawing.Point(972, 560);
            this.btn_STOP.MouseState = MaterialSkin.MouseState.HOVER;
            this.btn_STOP.Name = "btn_STOP";
            this.btn_STOP.Primary = true;
            this.btn_STOP.Size = new System.Drawing.Size(81, 36);
            this.btn_STOP.TabIndex = 41;
            this.btn_STOP.Text = "停止运动";
            this.btn_STOP.UseVisualStyleBackColor = true;
            this.btn_STOP.Click += new System.EventHandler(this.btn_STOP_Click);
            // 
            // btn_clearFault
            // 
            this.btn_clearFault.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_clearFault.AutoSize = true;
            this.btn_clearFault.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_clearFault.Depth = 0;
            this.btn_clearFault.Font = new System.Drawing.Font("宋体", 42F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_clearFault.Icon = null;
            this.btn_clearFault.Location = new System.Drawing.Point(1059, 560);
            this.btn_clearFault.MouseState = MaterialSkin.MouseState.HOVER;
            this.btn_clearFault.Name = "btn_clearFault";
            this.btn_clearFault.Primary = true;
            this.btn_clearFault.Size = new System.Drawing.Size(81, 36);
            this.btn_clearFault.TabIndex = 42;
            this.btn_clearFault.Text = "清除报错";
            this.btn_clearFault.UseVisualStyleBackColor = true;
            this.btn_clearFault.Click += new System.EventHandler(this.btn_clearFault_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.tbox_delayTime);
            this.groupBox3.Controls.Add(this.btn_readB);
            this.groupBox3.Controls.Add(this.btn_readA);
            this.groupBox3.Controls.Add(this.tbox_BPosition);
            this.groupBox3.Controls.Add(this.btn_statABMotion);
            this.groupBox3.Controls.Add(this.tbox_APosition);
            this.groupBox3.Location = new System.Drawing.Point(641, 228);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(200, 163);
            this.groupBox3.TabIndex = 43;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "往返运动";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("阿里巴巴普惠体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label18.Location = new System.Drawing.Point(6, 74);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(37, 20);
            this.label18.TabIndex = 53;
            this.label18.Text = "延时";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("阿里巴巴普惠体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label12.Location = new System.Drawing.Point(6, 46);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(45, 20);
            this.label12.TabIndex = 52;
            this.label12.Text = "位置2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("阿里巴巴普惠体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(6, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 20);
            this.label1.TabIndex = 51;
            this.label1.Text = "位置1";
            // 
            // tbox_delayTime
            // 
            this.tbox_delayTime.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tbox_delayTime.Depth = 0;
            this.tbox_delayTime.Hint = "延时时间";
            this.tbox_delayTime.Location = new System.Drawing.Point(60, 75);
            this.tbox_delayTime.MaxLength = 32767;
            this.tbox_delayTime.MouseState = MaterialSkin.MouseState.HOVER;
            this.tbox_delayTime.Name = "tbox_delayTime";
            this.tbox_delayTime.PasswordChar = '\0';
            this.tbox_delayTime.SelectedText = "";
            this.tbox_delayTime.SelectionLength = 0;
            this.tbox_delayTime.SelectionStart = 0;
            this.tbox_delayTime.Size = new System.Drawing.Size(87, 23);
            this.tbox_delayTime.TabIndex = 50;
            this.tbox_delayTime.TabStop = false;
            this.tbox_delayTime.UseSystemPasswordChar = false;
            // 
            // btn_readB
            // 
            this.btn_readB.AutoSize = true;
            this.btn_readB.Font = new System.Drawing.Font("阿里巴巴普惠体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_readB.Location = new System.Drawing.Point(153, 47);
            this.btn_readB.Name = "btn_readB";
            this.btn_readB.Size = new System.Drawing.Size(42, 22);
            this.btn_readB.TabIndex = 49;
            this.btn_readB.Text = "读取";
            this.btn_readB.Click += new System.EventHandler(this.btn_readB_Click);
            // 
            // btn_readA
            // 
            this.btn_readA.AutoSize = true;
            this.btn_readA.Font = new System.Drawing.Font("阿里巴巴普惠体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_readA.Location = new System.Drawing.Point(153, 17);
            this.btn_readA.Name = "btn_readA";
            this.btn_readA.Size = new System.Drawing.Size(42, 22);
            this.btn_readA.TabIndex = 48;
            this.btn_readA.Text = "读取";
            this.btn_readA.Click += new System.EventHandler(this.btn_readA_Click);
            // 
            // tbox_BPosition
            // 
            this.tbox_BPosition.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tbox_BPosition.Depth = 0;
            this.tbox_BPosition.Hint = "B点 ";
            this.tbox_BPosition.Location = new System.Drawing.Point(60, 46);
            this.tbox_BPosition.MaxLength = 32767;
            this.tbox_BPosition.MouseState = MaterialSkin.MouseState.HOVER;
            this.tbox_BPosition.Name = "tbox_BPosition";
            this.tbox_BPosition.PasswordChar = '\0';
            this.tbox_BPosition.SelectedText = "";
            this.tbox_BPosition.SelectionLength = 0;
            this.tbox_BPosition.SelectionStart = 0;
            this.tbox_BPosition.Size = new System.Drawing.Size(87, 23);
            this.tbox_BPosition.TabIndex = 47;
            this.tbox_BPosition.TabStop = false;
            this.tbox_BPosition.UseSystemPasswordChar = false;
            // 
            // btn_statABMotion
            // 
            this.btn_statABMotion.AutoSize = true;
            this.btn_statABMotion.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_statABMotion.Depth = 0;
            this.btn_statABMotion.Icon = null;
            this.btn_statABMotion.Location = new System.Drawing.Point(6, 121);
            this.btn_statABMotion.MouseState = MaterialSkin.MouseState.HOVER;
            this.btn_statABMotion.Name = "btn_statABMotion";
            this.btn_statABMotion.Primary = true;
            this.btn_statABMotion.Size = new System.Drawing.Size(51, 36);
            this.btn_statABMotion.TabIndex = 44;
            this.btn_statABMotion.Text = "运动";
            this.btn_statABMotion.UseVisualStyleBackColor = true;
            this.btn_statABMotion.Click += new System.EventHandler(this.btn_statABMotion_Click);
            // 
            // tbox_APosition
            // 
            this.tbox_APosition.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tbox_APosition.Depth = 0;
            this.tbox_APosition.Hint = "A点";
            this.tbox_APosition.Location = new System.Drawing.Point(60, 17);
            this.tbox_APosition.MaxLength = 32767;
            this.tbox_APosition.MouseState = MaterialSkin.MouseState.HOVER;
            this.tbox_APosition.Name = "tbox_APosition";
            this.tbox_APosition.PasswordChar = '\0';
            this.tbox_APosition.SelectedText = "";
            this.tbox_APosition.SelectionLength = 0;
            this.tbox_APosition.SelectionStart = 0;
            this.tbox_APosition.Size = new System.Drawing.Size(87, 23);
            this.tbox_APosition.TabIndex = 42;
            this.tbox_APosition.TabStop = false;
            this.tbox_APosition.UseSystemPasswordChar = false;
            // 
            // LED_enable
            // 
            this.LED_enable.Image = global::预调试助手.Properties.Resources.Off;
            this.LED_enable.Location = new System.Drawing.Point(572, 72);
            this.LED_enable.Name = "LED_enable";
            this.LED_enable.Size = new System.Drawing.Size(19, 17);
            this.LED_enable.TabIndex = 15;
            // 
            // LED_inposition
            // 
            this.LED_inposition.Image = global::预调试助手.Properties.Resources.Off;
            this.LED_inposition.Location = new System.Drawing.Point(652, 72);
            this.LED_inposition.Name = "LED_inposition";
            this.LED_inposition.Size = new System.Drawing.Size(19, 17);
            this.LED_inposition.TabIndex = 14;
            // 
            // LED_ACCing
            // 
            this.LED_ACCing.Image = global::预调试助手.Properties.Resources.Off;
            this.LED_ACCing.Location = new System.Drawing.Point(492, 72);
            this.LED_ACCing.Name = "LED_ACCing";
            this.LED_ACCing.Size = new System.Drawing.Size(19, 17);
            this.LED_ACCing.TabIndex = 13;
            // 
            // LED_moveing
            // 
            this.LED_moveing.Image = global::预调试助手.Properties.Resources.Off;
            this.LED_moveing.Location = new System.Drawing.Point(412, 72);
            this.LED_moveing.Name = "LED_moveing";
            this.LED_moveing.Size = new System.Drawing.Size(19, 17);
            this.LED_moveing.TabIndex = 12;
            // 
            // winMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1285, 600);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.btn_clearFault);
            this.Controls.Add(this.btn_STOP);
            this.Controls.Add(this.Enable_baidu);
            this.Controls.Add(this.rbtn_sim);
            this.Controls.Add(this.rbtn_TcpIp);
            this.Controls.Add(this.ucBtnExt1);
            this.Controls.Add(this.btn_connect);
            this.Controls.Add(this.btn_disable);
            this.Controls.Add(this.btn_enable);
            this.Controls.Add(this.cbBox_enable);
            this.Controls.Add(this.materialLabel1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.rbox_terminal);
            this.Controls.Add(this.tbox_IP);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.gbox_motionprofile);
            this.Controls.Add(this.gbox_positon);
            this.Controls.Add(this.LED_enable);
            this.Controls.Add(this.LED_inposition);
            this.Controls.Add(this.LED_ACCing);
            this.Controls.Add(this.LED_moveing);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.gbox_fault);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "winMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "预调试助手";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.winMain_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gbox_fault.ResumeLayout(false);
            this.gbox_fault.PerformLayout();
            this.gbox_motionprofile.ResumeLayout(false);
            this.gbox_motionprofile.PerformLayout();
            this.gbox_positon.ResumeLayout(false);
            this.gbox_positon.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox gbox_fault;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox gbox_motionprofile;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Timer time_Update;
        private System.Windows.Forms.GroupBox gbox_positon;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label LED_moveing;
        private System.Windows.Forms.Label LED_ACCing;
        private System.Windows.Forms.Label LED_inposition;
        private System.Windows.Forms.Label LED_enable;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.CheckBox cbox_useJOG;
        private System.Windows.Forms.TextBox tbox_IP;
        private System.Windows.Forms.RichTextBox rbox_terminal;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.SaveFileDialog saveFile;
        private System.Windows.Forms.ComboBox cbBox_enable;
        private MaterialSkin.Controls.MaterialRaisedButton btn_set0;
        private MaterialSkin.Controls.MaterialRaisedButton btn_JOGRE;
        private MaterialSkin.Controls.MaterialRaisedButton btn_JOGNE;
        private MaterialSkin.Controls.MaterialRaisedButton btn_save;
        private MaterialSkin.Controls.MaterialRaisedButton btn_clear;
        private MaterialSkin.Controls.MaterialRaisedButton btn_send;
        private MaterialSkin.Controls.MaterialLabel materialLabel1;
        private MaterialSkin.Controls.MaterialRaisedButton btn_enable;
        private MaterialSkin.Controls.MaterialRaisedButton btn_disable;
        private MaterialSkin.Controls.MaterialFlatButton btn_connect;
        private MaterialSkin.Controls.MaterialFlatButton ucBtnExt1;
        private MaterialSkin.Controls.MaterialRadioButton rbtn_TcpIp;
        private MaterialSkin.Controls.MaterialRadioButton rbtn_sim;
        private MaterialSkin.Controls.MaterialCheckBox Enable_baidu;
        private MaterialSkin.Controls.MaterialSingleLineTextField tbox_Terminal;
        private MaterialSkin.Controls.MaterialSingleLineTextField tbox_position_dis;
        private MaterialSkin.Controls.MaterialSingleLineTextField tbox_JOGspeed;
        private MaterialSkin.Controls.MaterialSingleLineTextField tbox_PE;
        private MaterialSkin.Controls.MaterialSingleLineTextField tbox_FVEL;
        private MaterialSkin.Controls.MaterialSingleLineTextField tbox_FPOS;
        private MaterialSkin.Controls.MaterialSingleLineTextField tbox_RPOS;
        private MaterialSkin.Controls.MaterialSingleLineTextField tbox_JERK;
        private MaterialSkin.Controls.MaterialSingleLineTextField tbox_KDEC;
        private MaterialSkin.Controls.MaterialSingleLineTextField tbox_DEC;
        private MaterialSkin.Controls.MaterialSingleLineTextField tbox_ACC;
        private MaterialSkin.Controls.MaterialRaisedButton btn_abposition;
        private MaterialSkin.Controls.MaterialRaisedButton btn_positive;
        private MaterialSkin.Controls.MaterialRaisedButton btn_NEposition;
        private MaterialSkin.Controls.MaterialRaisedButton btn_STOP;
        private MaterialSkin.Controls.MaterialSingleLineTextField tbox_VEL;
        private MaterialSkin.Controls.MaterialRaisedButton btn_clearFault;
        private System.Windows.Forms.GroupBox groupBox3;
        private MaterialSkin.Controls.MaterialSingleLineTextField tbox_BPosition;
        private MaterialSkin.Controls.MaterialRaisedButton btn_statABMotion;
        private MaterialSkin.Controls.MaterialSingleLineTextField tbox_APosition;
        private System.Windows.Forms.Label btn_readB;
        private System.Windows.Forms.Label btn_readA;
        private MaterialSkin.Controls.MaterialSingleLineTextField tbox_delayTime;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label1;
    }
}

